const Discord = require("discord.js");
const client = new Discord.Client();

const fs = require("fs");
const db = require('quick.db');

const request = require('request');

const moment = require("moment");
require("moment-duration-format");

const ayarlar = require("./ayarlar/bot.json");

//------------------ Komut Yükleme -----------------\\

client.on("message", async message => {
let prefix = await db.fetch(`prefix.${message.guild.id}`) || ayarlar.prefix 
const messageArray = message.content.split(" ");
const cmd = messageArray[0].toLowerCase();
const args = messageArray.slice(1);
if (!message.content.startsWith(prefix)) return;
const commandfile =
client.commands.get(cmd.slice(prefix.length)) ||
client.commands.get(client.aliases.get(cmd.slice(prefix.length)));
if (commandfile) commandfile.run(client, message, args);
});

client.commands = new Discord.Collection();
client.aliases = new Discord.Collection();

fs.readdir("./komutlar/", (err, files) => {
  const jsfiles = files.filter(f => f.split(".").pop() === "js");
  if (jsfiles.length <= 0) {
  return console.log("Herhangi bir komut bulunamadı!");
  }
  jsfiles.forEach(file => {
  console.log(`Yüklenen Komut: ${file}`);
  const command = require(`./komutlar/${file}`);
  client.commands.set(command.config.name, command);
  command.config.aliases.forEach(alias => {
  client.aliases.set(alias, command.config.name);
});
});
});

//---------------------- Token Bildiri ---------------------\\

client.login(ayarlar.token)
.then(function() {
console.log("Token doğru! Bot aktif ediliyor.")
}, function(err) {
console.log("Token yanlış! Bot başlatılamıyor.")
setInterval(function() {
process.exit(0)
}, 20000);
})

//-------------- Kendini Sağırlaştırma Komutu ---------------\\

client.on('voiceStateUpdate', async (___, newState) => {
if (
newState.member.user.bot &&
newState.channelID &&
newState.member.user.id == client.user.id &&
!newState.selfDeaf
) {
newState.setSelfDeaf(true);
}
});

//------------------- Sabit Oynuyor --------------------\\

//client.on('ready', () => {
//  client.user.setActivity(`!yardım 🤍 Vanilya`, {"type": "WATCHING"})
//});

//------------------- Minecraft Oynuyor --------------------\\

var ip = ayarlar.ip;
var url = 'http://mcapi.tc/?' + ip + '/json';

function update() { request(url, function(err, response, body) {
      if(err) {
        console.log(err);
      }

      body = JSON.parse(body);
      var status = ' ' + body.players + " Kişi Riva'da";
      
      if(body.players) {
        if((body.description == "Bakımdayız") || (body.players >= body.max_players))
        {
          client.user.setStatus('idle').catch(console.error);
        } else {
          client.user.setStatus('online').catch(console.error);
        }
        } else {
          client.user.setStatus('dnd').catch(console.error);
        }
        client.user.setActivity(status, { type: 'PLAYING' });
  }); 
}

client.on("ready", () => {
  client.setInterval(update,15000);
})

//------------- Botun Sunucuya Giriş Mesajı ---------------\\

const ilk = new Discord.MessageEmbed()
.setColor("#000000")
.setThumbnail()
.setAuthor(`${ayarlar.botisim}${ayarlar.isim_eki} rolünü yukarıda tutmayı unutmayın!`)
.addField(`${ayarlar.kalp} \`Bilgilendirme\``, `**Selam dondurmaa, beni sunucuna eklediğin için sana minettarım.**`)
.addField(`${ayarlar.vanilya} \`Prefix\``, `**${ayarlar.botisim}${ayarlar.isim_eki} prefix'ini değiştirmek istersen \`${ayarlar.prefix}prefix\` yazabilirsin.**`)
.addField(`${ayarlar.onayla} \`Nasıl Kullanılır?\``, `**${ayarlar.botisim}${ayarlar.isim_eki} özelliklerini kullanabilmek için \`${ayarlar.prefix}yardım\` yazabilirsin.**`)
.setFooter(`${ayarlar.botisim} sizlere yardımcı olmak için burada`)
.setTimestamp()
.setImage('https://i.hizliresim.com/e4llh5i.gif');

client.on("guildCreate", guild => {

let defaultChannel = "";
guild.channels.cache.forEach((channel) => {
if(channel.type == "text" && defaultChannel == "") {
if(channel.permissionsFor(guild.me).has("SEND_MESSAGES")) {
defaultChannel = channel;
}
}
})
defaultChannel.send(ilk)
});

//----------------- Botun Etiket Cevabı -----------------\\

client.on('message', async msg => {
  let prefix = await db.fetch(`prefix.${msg.guild.id}`) || ayarlar.prefix 
  const etiket = new Discord.MessageEmbed()
  if(msg.content == `<@!${client.user.id}>`) return msg.channel.send(etiket.setColor("#000000").setTitle(`Selam Vanilyalı Dondurma!`).setDescription(`${ayarlar.vanilya} **İşte prefix'im** \`${prefix}\``)).then(a => a.delete({timeout: 20000}));
});

//--------------- Sayaç HG ----------------//

client.on("guildMemberAdd", async member => {
  const kanal = await db.fetch(`sayacK_${member.guild.id}`);
  if (!kanal) return;
  const sayaç = await db.fetch(`sayacS_${member.guild.id}`);
    const sonuç = sayaç - member.guild.memberCount;
  const mesaj = await db.fetch(`sayacHG_${member.guild.id}`)
  if (!mesaj) {
    return client.channels.cache.get(kanal).send(`:inbox_tray: <@!${member.user.id}> **aramıza katıldı** \`${sayaç}\` **kişi olmamıza** \`${sonuç}\` **kişi kaldı artık** \`${member.guild.memberCount}\` **kişiyiz!**`);
  }
  if (member.guild.memberCount == sayaç) {
    db.delete(`sayacK_${member.guild.id}`)
    db.delete(`sayacS_${member.guild.id}`)
    return client.channels.cache.get(kanal).send(`:loudspeaker: Sayaç hedefine ulaşıldı ve sayaç kapatıldı! \`${member.guild.memberCount}\` kişiyiz!`)
  }
  if (mesaj) {
    const geldi = mesaj.replace("+üye", `<@!${member.user.id}>`).replace("+sunucu", `${member.guild.name}`).replace("+toplamüye", `${member.guild.memberCount}`).replace("+kalanüye", `${sonuç}`).replace("+hedefüye", `${sayaç}`)
    return client.channels.cache.get(kanal).send(geldi);
  }
});

//--------------- Sayaç BB ----------------//

client.on("guildMemberRemove", async member => {
  const kanal = await db.fetch(`sayacK_${member.guild.id}`);
  const sayaç = await db.fetch(`sayacS_${member.guild.id}`);
  const sonuç = sayaç - member.guild.memberCount;
  const mesaj = await db.fetch(`sayacBB_${member.guild.id}`)
  if (!kanal) return;
  if (!sayaç) return;
  if (!mesaj) {
    return client.channels.cache.get(kanal).send(`:outbox_tray: <@!${member.user.id}> **aramızdan ayrıldı** \`${sayaç}\` **kişi olmamıza** \`${sonuç}\` **kişi kaldı artık** \`${member.guild.memberCount}\` **kişiyiz!**`);
      }
  if (mesaj) {
    const gitti = mesaj.replace("+üye", `<@!${member.user.id}>`).replace("+sunucu", `${member.guild.name}`).replace("+toplamüye", `${member.guild.memberCount}`).replace("+kalanüye", `${sonuç}`).replace("+hedefüye", `${sayaç}`)
    return client.channels.cache.get(kanal).send(gitti);
  }
});

//--------------- Kayıt Sistemi ----------------//

client.on('guildMemberAdd', async member => {

  let kanal = await db.fetch(`kayit.kanal.${member.guild.id}`);
  let yetkili = await db.fetch(`yetkili.${member.guild.id}`);

  let rol = await db.fetch(`kayitsiz.${member.guild.id}`);
  if (rol) {
    member.roles.add(rol)
  }
  else
  {
    rol = '';
  }

  let cmfzaman = new Date().getTime() - member.user.createdAt.getTime();
  let cmfzaman2 = new Date().getTime() - member.user.createdAt.getTime()

  const mapping = {
    " ": "   ",
    '0': '<a:0_:926196952834646027>',
    '1': '<a:1_:926196954080370768>',
    '2': '<a:2_:926196954785013840>',
    '3': '<a:3_:926196954340397077>',
    '4': '<a:4_:926196954361380884>',
    '5': '<a:5_:926196954613039196>',
    '6': '<a:6_:926196954248142849>',
    '7': '<a:7_:926197011999514696>',
    '8': '<a:8_:926197013098410045>',
    '9': '<a:9_:926197012792221755>'}
    let üyesayısı = `${member.guild.memberCount.toString()}`
    .split("")
    .map(c => mapping[c] || c)
    .join("")

  var CodeMareFi = [];
    if(cmfzaman < 1296000000)
      CodeMareFi = "Güvenilir Değil ❌"
    if(cmfzaman > 1296000000)
      CodeMareFi = `Güvenilir ${ayarlar.onayla}`

  const zaman = moment.duration(cmfzaman2).format(` YY **[Yıl,]** DD **[Gün,]** HH **[Saat,]** mm **[Dakika,]** ss **[Saniye]**`) 
  
  client.channels.cache.get(kanal).send(new Discord.MessageEmbed().setTitle(`Birisi Sunucuya Giriş Yaptı`).setColor('#000000').setDescription(`**${ayarlar.kalp} Sunucuya Hoş Geldin <@${member.id}>
  
  ${ayarlar.vanilya} Seninle Beraber Sunucumuzda ${üyesayısı} Değerli İnsan Oldu.

  ${ayarlar.vanilya} Hesabın \`${zaman}\` Önce Oluşturulmuş.

  ${ayarlar.vanilya} Kullanıcı ${CodeMareFi}
  
  ${ayarlar.vanilya} <@&${yetkili}> Rolündeki Yetkililer Seninle İlgilenicektir.**`).setFooter(`${ayarlar.botisim} | Kayıt Sistemi`, client.user.avatarURL()).setTimestamp().setImage('https://i.hizliresim.com/lre903g.gif'))
})

//--------------- OtoRol Sistem ----------------//

client.on("guildMemberAdd", async member => {
  let rol = await db.fetch(`otoRL_${member.guild.id}`);
  if (rol) {
    return member.roles.add(rol)
  }
  else
  {
    rol = '';
  }
});

//--------------- Oto İsim & Tag Sistem ----------------//

client.on('guildMemberAdd', async member => {
  let user = member.user;
  let guild = member.guild;
  const kanalFetch = await db.fetch(`otoisim.log.${guild.id}`);
  const otoisimFetch = await db.fetch(`otoisim.ad.${guild.id}`);
  if(!otoisimFetch) return;
  let kanal;
  if(kanalFetch) kanal = guild.channels.cache.get(kanalFetch);

  let otoisim;
  if (otoisim = otoisimFetch.replace('+kullanıcı', user.username));

  member.setNickname(otoisim);
  if(kanal) kanal.send(new Discord.MessageEmbed().setTitle(`Oto İsim Değiştirildi`).setColor("#000000").setDescription(`${member} **Sunucuya giriş yaptı!**\n\n${ayarlar.vanilya} **Eski isim** \`${user.username}\`\n\n${ayarlar.vanilya} **Yeni isim \`${otoisim}\`**`));
  });

//--------------- TagRol Sistem ----------------//

client.on('userUpdate', (oldUser, newUser) => {
  client.guilds.cache.forEach(async guild => {
  if(!guild.members.cache.get(newUser.id)) return;
  const tagBot = await db.fetch(`tagrol.tag.${guild.id}`);
  const rolBot = await db.fetch(`tagrol.rol.${guild.id}`);
  const logBot = await db.fetch(`tagrol.log.${guild.id}`);
  if(!tagBot || !rolBot || !logBot) return;
  let tag = tagBot;
  let rol = guild.roles.cache.get(rolBot);
  let log = guild.channels.cache.get(logBot);
  if(oldUser.username === newUser.username) return;
  if(newUser.username.includes(tag) && !oldUser.username.includes(tag)) {
  guild.members.cache.get(newUser.id).roles.add(rol);
  log.send(new Discord.MessageEmbed()
  .setColor("#000000")
  .setTitle('Birisi Tagı Aldı')
  .setDescription(`${ayarlar.vanilya} ${newUser} \`${tag}\` **Tagını aldığı için ${rol} rolünü verdim.**`)
  .setTimestamp()
  .setFooter(`${ayarlar.botisim} | Tagrol Log`));
  }
  if(oldUser.username.includes(tag) && !newUser.username.includes(tag)) {
  guild.members.cache.get(newUser.id).roles.remove(rol);
  log.send(new Discord.MessageEmbed()
  .setColor('#000000')
  .setTitle('Birisi Tagı Çıkardı')
  .setDescription(`${ayarlar.vanilya} ${newUser} \`${tag}\` **Tagını çıkardığı için ${rol} rolünü aldım.**`)
  .setTimestamp()
  .setFooter(`${ayarlar.botisim} | Tagrol Log`));
}
})
})

//--------------- Yasaklı Tag ----------------//

client.on('guildMemberAdd', async member => {
  let guild = member.guild; 
  let user = guild.members.cache.get(member.id);
  
  const tag = await db.fetch(`yasak-tag.${guild.id}`)
  const sayı = await db.fetch(`atıldın.${guild.id}.${user.id}`)
  if(user.user.username.includes(tag)) {
    
  if(sayı === null) {
  await db.add(`atıldın.${guild.id}.${user.id}`, 1)
  user.send(new Discord.MessageEmbed()
  .setColor('RED')
  .setAuthor(guild.name, guild.iconURL)
  .setDescription(`Sunucumuzun yasaklı tagında bulunduğunuz için atıldınız, tekrar giriş yapmayı denerseniz **yasaklanacaksınız**!`))
  await user.kick() }
  
  if(sayı === 1) {
  await db.delete(`atıldın.${guild.id}.${user.id}`)
  user.send(new Discord.MessageEmbed()
  .setColor('RED')
  .setAuthor(guild.name, guild.iconURL)
  .setDescription(`Sunucumuzun yasaklı tagında bulunduğunuz için atılmıştınız, tekrar giriş yapmayı denediğiniz için **${guild.name}** sunucusundan kalıcı olarak **yasaklandınız**!`))
  await user.ban() } }
    
})

//--------------- AFK Sistem ----------------//

client.on("message" , message => {
  if(!message.guild) return;
  if(message.content.startsWith(ayarlar.prefix + 'afk')) return;

  let afk = message.mentions.users.first()
  let kisi = db.fetch(`kisiid_${message.author.id}_${message.guild.id}`)
  let kisiisim = db.fetch(`kisiisim_${message.author.id}_${message.guild.id}`)

  if(afk){
    let sebep = db.fetch(`afk_sebep_${afk.id}_${message.guild.id}`)
    let kisi2 = db.fetch(`kisiid_${afk.id}_${message.guild.id}`)

    if(message.content.includes(kisi2)){

      const embed = new Discord.MessageEmbed()
      .setDescription(`**${ayarlar.vanilya} ${message.author} Etiketlemiş Olduğun <@!${kisi2}> şu an \`${sebep}\` sebebiyle AFK**`)
      .setColor('#000000')
      .setTimestamp()
      .setFooter(`${message.author.username} tarafından kullanıldı`, client.user.avatarURL())
      message.channel.send(embed)
    }
  }
  if(message.author.id === kisi) {
    db.delete(`afk_sebep_${message.author.id}_${message.guild.id}`)
    db.delete(`kisiid_${message.author.id}_${message.guild.id}`)
    db.delete(`kisiisim_${message.author.id}_${message.guild.id}`)

    message.member.setNickname(kisiisim)

    const embed = new Discord.MessageEmbed()
    .setAuthor(`Hoş geldin ${message.author.username}`, message.author.avatarURL({dynamic: true, size: 2048}))
    .setDescription(`**${ayarlar.onayla} <@!${kisi}> artık \`AFK\` modunda değilsin.**`)
    .setColor('#000000')
    .setTimestamp()
    .setFooter(`${message.author.username} tarafından kullanıldı`, client.user.avatarURL())
    message.channel.send(embed)
  }  
})

//--------------- Oto Cevap Sistem ----------------//

client.on('message', async msg => {
  let ozelkomut = await db.fetch(`sunucuKomut_${msg.guild.id}`);
  let ozelkomutYazi;
  if (ozelkomut == null) ozelkomutYazi = 'Burayı silme yoksa hatalı olur'
  else ozelkomutYazi = ''+ ozelkomut +''
  if (msg.content.toLowerCase() === ozelkomutYazi) {
      let mesaj = await db.fetch(`sunucuMesaj_${msg.guild.id}`);
  let mesajYazi;
  if (mesaj == null) mesajYazi = 'Burayı silme yoksa hatalı olur'
  else mesajYazi = ''+ mesaj +''
    msg.channel.send(mesajYazi)
  }
});

client.on('message', async msg => {
  let ozelkomut = await db.fetch(`sunucuKomut2_${msg.guild.id}`);
  let ozelkomutYazi;
  if (ozelkomut == null) ozelkomutYazi = 'Burayı silme yoksa hatalı olur'
  else ozelkomutYazi = ''+ ozelkomut +''
  if (msg.content.toLowerCase() === ozelkomutYazi) {
      let mesaj = await db.fetch(`sunucuMesaj2_${msg.guild.id}`);
  let mesajYazi;
  if (mesaj == null) mesajYazi = 'Burayı silme yoksa hatalı olur'
  else mesajYazi = ''+ mesaj +''
    msg.channel.send(mesajYazi)
  }
});

client.on('message', async msg => {
  let ozelkomut = await db.fetch(`sunucuKomut3_${msg.guild.id}`);
  let ozelkomutYazi;
  if (ozelkomut == null) ozelkomutYazi = 'Burayı silme yoksa hatalı olur'
  else ozelkomutYazi = ''+ ozelkomut +''
  if (msg.content.toLowerCase() === ozelkomutYazi) {
      let mesaj = await db.fetch(`sunucuMesaj3_${msg.guild.id}`);
  let mesajYazi;
  if (mesaj == null) mesajYazi = 'Burayı silme yoksa hatalı olur'
  else mesajYazi = ''+ mesaj +''
    msg.channel.send(mesajYazi)
  }
});

//--------------- Oto Mesaj Sistem ----------------//

client.on('message', async message => {
  const sistem = await db.fetch(`mesajs.${message.guild.id}`);
  if(!sistem) return;
      var sa = ["sa","sea","selam","selamın aleyküm","selamın aleykum","selamun aleyküm","selamun aleykum","selamm","hello","hi","merhaba","heyoo","heyo"]
      if(sa.includes(message.content.toLowerCase())){
      return message.channel.send(new Discord.MessageEmbed().setDescription(`${message.author} **Selammm, hoş geldin!** <a:nikko:901877230844674078>`));
}});

client.on('message', async message => {
  const sistem = await db.fetch(`mesajs.${message.guild.id}`);
  if(!sistem) return;
      var sa = ["günaydın","gunaydın","güno","günoo","günooo","guno","gunoo","gunooo","günno"]
      if(sa.includes(message.content.toLowerCase())){
      return message.channel.send(new Discord.MessageEmbed().setDescription(`${message.author} **Günaydınnn!** <a:nikko:901877230844674078>`));
}});

client.on('message', async message => {
  const sistem = await db.fetch(`mesajs.${message.guild.id}`);
  if(!sistem) return;
      var sa = ["iyigeceler","iyi geceler","İyi geceler","iyİ geceler","ig","ıg","igg","iyi gecler","igig","ıgg"]
      if(sa.includes(message.content.toLowerCase())){
      return message.channel.send(new Discord.MessageEmbed().setDescription(`${message.author} **İyi geceler tatlı rüyalar!** <a:nikko:901877230844674078>`));
}});

//-------------- Küfür Koruması ----------------//

client.on('message', async message => {
  const küfür = await db.fetch(`küfür.${message.guild.id}`);
  if(!küfür) return;
  const blacklist = ["abaza","abazan","aq","ağzınasıçayım","ahmak","ambiti","ambiti","amcığı","amcığın","amcığını","amcığınızı","amcık","amcıkhoşafı","amcıklama","amcıklandı","amcik","amck","amckl","amcklama","amcklaryla","amckta","amcktan","amcuk","amık","amına","amınako","amınakoy","amınakoyarım","amınakoyayım","amınakoyim","amınakoyyim","amınas","amınasikem","amınasokam","amınferyadı","amını","amınıs","amınoglu","amınoğlu","amınoğli","amısına","amısını","amina","aminakoyarim","aminakoyayım","aminakoyayim","aminakoyim","aminda","amindan","amindayken","amini","aminiyarraaniskiim","aminoglu","aminoglu","amiyum","amk","amkafa","amkçocuğu","amlarnzn","amlı","amm","amna","amnda","amndaki","amngtn","amnn","amq","amsız","amsiz","amuna","ana","anaaann","anal","anan","anana","anandan","ananı","ananı","ananın","ananınam","ananınamı","ananındölü","ananınki","ananısikerim","ananısikerim","ananısikeyim","ananısikeyim","ananızın","ananızınam","anani","ananin","ananisikerim","ananisikerim","ananisikeyim","ananisikeyim","anann","ananz","anas","anasını","anasınınam","anasıorospu","anasi","anasinin","angut","anneni","annenin","annesiz","aptal","aq","a.q","a.q.","aq.","atkafası","atmık","avrat","babaannesikaşar","babanı","babanın","babani","babasıpezevenk","bacına","bacını","bacının","bacini","bacn","bacndan","bitch","bok","boka","bokbok","bokça","bokkkumu","boklar","boktan","boku","bokubokuna","bokum","bombok","boner","bosalmak","boşalmak","çük","dallama","daltassak","dalyarak","dalyarrak","dangalak","dassagi","diktim","dildo","dingil","dingilini","dinsiz","dkerim","domal","domalan","domaldı","domaldın","domalık","domalıyor","domalmak","domalmış","domalsın","domalt","domaltarak","domaltıp","domaltır","domaltırım","domaltip","domaltmak","dölü","eben","ebeni","ebenin","ebeninki","ecdadını","ecdadini","embesil","fahise","fahişe","feriştah","ferre","fuck","fucker","fuckin","fucking","gavad","gavat","geber","geberik","gebermek","gebermiş","gebertir","gerızekalı","gerizekalı","gerizekali","gerzek","gotlalesi","gotlu","gotten","gotundeki","gotunden","gotune","gotunu","gotveren","göt","götdeliği","götherif","götlalesi","götlek","götoğlanı","götoğlanı","götoş","götten","götü","götün","götüne","götünekoyim","götünekoyim","götünü","götveren","götveren","götverir","gtveren","hasiktir","hassikome","hassiktir","hassiktir","hassittir","ibine","ibinenin","ibne","ibnedir","ibneleri","ibnelik","ibnelri","ibneni","ibnenin","ibnesi","ipne","itoğluit","kahpe","kahpenin","kaka","kaltak","kancık","kancik","kappe","kavat","kavatn","kocagöt","koduğmunun","kodumun","kodumunun","koduumun","mal","malafat","malak","manyak","meme","memelerini","oc","ocuu","ocuun","0Ç","o.çocuğu","orosbucocuu","orospu","orospucocugu","orospuçoc","orospuçocuğu","orospuçocuğudur","orospuçocukları","orospudur","orospular","orospunun","orospununevladı","orospuydu","orospuyuz","orrospu","oruspu","oruspuçocuğu","oruspuçocuğu","osbir","öküz","penis","pezevek","pezeven","pezeveng","pezevengi","pezevenginevladı","pezevenk","pezo","pic","pici","picler","piç","piçinoğlu","piçkurusu","piçler","pipi","pisliktir","porno","pussy","puşt","puşttur","s1kerim","s1kerm","s1krm","sakso","salaak","salak","serefsiz","sexs","sıçarım","sıçtığım","sıkecem","sicarsin","sie","sik","sikdi","sikdiğim","sike","sikecem","sikem","siken","sikenin","siker","sikerim","sikerler","sikersin","sikertir","sikertmek","sikesen","sikey","sikeydim","sikeyim","sikeym","siki","sikicem","sikici","sikien","sikienler","sikiiim","sikiiimmm","sikiim","sikiir","sikiirken","sikik","sikil","sikildiini","sikilesice","sikilmi","sikilmie","sikilmis","sikilmiş","sikilsin","sikim","sikimde","sikimden","sikime","sikimi","sikimiin","sikimin","sikimle","sikimsonik","sikimtrak","sikin","sikinde","sikinden","sikine","sikini","sikip","sikis","sikisek","sikisen","sikish","sikismis","sikiş","sikişen","sikişme","sikitiin","sikiyim","sikiym","sikiyorum","sikkim","sikleri","sikleriii","sikli","sikm","sikmek","sikmem","sikmiler","sikmisligim","siksem","sikseydin","sikseyidin","siksin","siksinler","siksiz","siksok","siksz","sikti","siktigimin","siktigiminin","siktiğim","siktiğimin","siktiğiminin","siktii","siktiim","siktiimin","siktiiminin","siktiler","siktim","siktimin","siktiminin","siktir","siktiret","siktirgit","siktirgit","siktirir","siktiririm","siktiriyor","siktirlan","siktirolgit","sittimin","skcem","skecem","skem","sker","skerim","skerm","skeyim","skiim","skik","skim","skime","skmek","sksin","sksn","sksz","sktiimin","sktrr","skyim","slaleni","sokam","sokarım","sokarim","sokarm","sokarmkoduumun","sokayım","sokaym","sokiim","soktuğumunun","sokuk","sokum","sokuş","sokuyum","soxum","sulaleni","sülalenizi","tasak","tassak","taşak","taşşak","s.k","s.keyim","vajina","vajinanı","xikeyim","yaaraaa","yalarım","yalarun","orospi","orospinin","orospının","orospı","yaraaam","yarak","yaraksız","yaraktr","yaram","yaraminbasi","yaramn","yararmorospunun","yarra","yarraaaa","yarraak","yarraam","yarraamı","yarragi","yarragimi","yarragina","yarragindan","yarragm","yarrağ","yarrağım","yarrağımı","yarraimin","yarrak","yarram","yarramin","yarraminbaşı","yarramn","yarran","yarrana","yarrrak","yavak","yavş","yavşak","yavşaktır","yrrak","zigsin","zikeyim","zikiiim","zikiim","zikik","zikim","ziksiin","ağzına","mk","amcık","amcıkağız","amcıkları","amık","amın","amına","amınakoyim","amınoğlu","amina","amini","amk","amq","anan","ananı","ananızı","ananizi","aminizi","aminii","avradını","avradini","anasını","b.k","bok","boktan","boşluk","dalyarak","dasak","dassak","daşak","daşşak","daşşaksız","durum","ensest","erotik","fahişe","fuck","g*t","g*tü","g*tün","g*tüne","g.t","gavat","gay","gerızekalıdır","gerizekalı","gerizekalıdır","got","gotunu","gotuze","göt","götü","götüne","götünü","götünüze","götüyle","götveren","götvern","guat","hasiktir","hasiktr","hastir","i.ne","ibne","ibneler","ibneliği","ipne","ipneler","it","iti","itler","kavat","kıç","kıro","kromusunuz","kromusunuz","lezle","lezler","nah","o.ç","oç.","okuz","orosbu","orospu","orospucocugu","orospular","otusbir","otuzbir","öküz","penis","pezevenk","pezevenkler","pezo","pic","piç","piçi","piçinin","piçler","pis","pok","pokunu","porn","porno","puşt","sex","s.tir","sakso","salak","sanane","sanane","sçkik","seks","serefsiz","serefsz","serefszler","sex","sıçmak","sıkerım","sıkm","sıktır","si.çmak","sicmak","sicti","sik","sikenin","siker","sikerim","sikerler","sikert","sikertirler","sikertmek","sikeyim","sikicem","sikiim","sikik","sikim","sikime","sikimi","sikiş","sikişken","sikişmek","sikm","sikmeyi","siksinler","siktiğim","siktimin","siktin","siktirgit","siktir","siktirgit","siktirsin","siqem","skiym","skm","skrm","sktim","sktir","sktirsin","sktr","sktroradan","sktrsn","snane","sokacak","sokarim","sokayım","sülaleni","şerefsiz","şerefsizler","şerefsizlerin","şerefsizlik","tasak","tassak","taşak","taşşak","travesti","yarak","yark","yarrağım","yarrak","yarramın","yarrk","yavşak","yrak","yrk","ebenin","ezik","o.ç.","orospu","öküz","pezevenk","piç","puşt","salak","salak","serefsiz","sik","sperm","bok","aq","a.q.","amk","amına","ebenin","ezik","fahişe","gavat","gavurundölü","gerizekalı","göte","götü","götüne","götünü","lan","mal","o.ç.","orospu","pezevenk","piç","puşt","salak","salak","serefsiz","sik","sikkırığı","sikerler","sikertmek","sikik","sikilmiş","siktir","sperm","taşak","totoş","yarak","yarrak","bok","aq","a.q.","amk","ebenin","fahişe","gavat","gerizakalı","gerizekalı","göt","göte","götü","götüne","götsün","piçsin","götsünüz","piçsiniz","götünüze","kıçınız","kıçınıza","götünü","hayvan","ibne","ipne","kahpe","kaltak","lan","mal","o.c","oc","manyak","o.ç.","oç","orospu","öküz","pezevenk","piç","puşt","salak","serefsiz","sik","sikkırığı","sikerler","sikertmek","sikik","sikiim","siktim","siki","sikilmiş","siktir","siktir","sperm","şerefsiz","taşak","totoş","yarak","yarrak","yosma","aq","a.q.","amk","amına","amınakoyim","amina","ammına","amna","sikim","sikiym","sikeyim","siktr","kodumun","amık","sikem","sikim","sikiym","s.iktm","s.ikerim","s.ktir","amg","am.k","a.mk","amık","rakı","rak","oruspu","oc","ananın","ananınki","bacının","bacını","babanın","sike","skim","skem","amcık","şerefsiz","piç","piçinoğlu","amcıkhoşafı","amınasokam","amkçocuğu","amınferyadı","amınoglu","piçler","sikerim","sikeyim","siktiğim","siktiğimin","amını","amına","amınoğlu","amk","ipne","ibne","serefsiz","şerefsiz","piç","piçkurusu","götün","götoş","yarrak","amcik","sıçarım","sıçtığım","aq","a.q","a.q.","aq.","a.g.","ag.","amınak","aminak","amınag","aminag","amınıs","amınas","ananı","babanı","anani","babani","bacını","bacini","ecdadını","ecdadini","sikeyim","sulaleni","sülaleni","dallama","dangalak","aptal","salak","gerızekalı","gerizekali","öküz","angut","dalyarak","sikiyim","sikeyim","götüne","götünü","siktirgit","siktirgit","siktirolgit","siktirolgit","siktir","hasiktir","hassiktir","hassiktir","dalyarak","dalyarrak","kancık","kancik","kaltak","orospu","oruspu","fahişe","fahise","pezevenk","pezo","kocagöt","ambiti","götünekoyim","götünekoyim","amınakoyim","aminakoyim","amınak","aminakoyayım","aminakoyayim","amınakoyarım","aminakoyarim","aminakoyarim","ananısikeyim","ananisikeyim","ananısikeyim","ananisikeyim","ananisikerim","ananısikerim","ananisikerim","ananısikerim","orospucocugu","oruspucocu","amk","amq","sikik","götveren","götveren","amınoğlu","aminoglu","amınoglu","gavat","kavat","anneni","annenin","ananın","ananin","dalyarak","sikik","amcık","siktir","piç","pic","sie","yarram","göt","meme","dildo","skcem","skerm","skerim","skecem","orrospu","annesiz","kahpe","kappe","yarak","yaram","dalaksız","yaraksız","amlı","s1kerim","s1kerm","s1krm","sikim","orospuçocukları", "oç"];
  const uyarılar = [
  '**Hey hey hey bunu yapma!**',
  '**Çok ayıp çooook görmiyim bida!**',
  '**Sen ahlaksız çocuk olmuşsun!**',
  '**Hey kendine gel bunu yapma!**'];
  let uyarımesaj = uyarılar[Math.floor(Math.random() * uyarılar.length)];
  if(blacklist.some(word => message.content.toLowerCase().includes(word))) {
  if(message.member.permissions.has('BAN_MEMBERS')) return;
  message.delete();
  message.channel.send(new Discord.MessageEmbed().setColor("#000000").setTitle('Küfür Kısıtlı').setDescription(`${message.author} ${uyarımesaj}`)).then(a => a.delete({timeout: 5000}));
  }
  })

  client.on('messageUpdate', async (newMessage, message) => {
    const küfür = await db.fetch(`küfür.${message.guild.id}`);
    if(!küfür) return;
    const blacklist = ["abaza","abazan","aq","ağzınasıçayım","ahmak","ambiti","ambiti","amcığı","amcığın","amcığını","amcığınızı","amcık","amcıkhoşafı","amcıklama","amcıklandı","amcik","amck","amckl","amcklama","amcklaryla","amckta","amcktan","amcuk","amık","amına","amınako","amınakoy","amınakoyarım","amınakoyayım","amınakoyim","amınakoyyim","amınas","amınasikem","amınasokam","amınferyadı","amını","amınıs","amınoglu","amınoğlu","amınoğli","amısına","amısını","amina","aminakoyarim","aminakoyayım","aminakoyayim","aminakoyim","aminda","amindan","amindayken","amini","aminiyarraaniskiim","aminoglu","aminoglu","amiyum","amk","amkafa","amkçocuğu","amlarnzn","amlı","amm","amna","amnda","amndaki","amngtn","amnn","amq","amsız","amsiz","amuna","ana","anaaann","anal","anan","anana","anandan","ananı","ananı","ananın","ananınam","ananınamı","ananındölü","ananınki","ananısikerim","ananısikerim","ananısikeyim","ananısikeyim","ananızın","ananızınam","anani","ananin","ananisikerim","ananisikerim","ananisikeyim","ananisikeyim","anann","ananz","anas","anasını","anasınınam","anasıorospu","anasi","anasinin","angut","anneni","annenin","annesiz","aptal","aq","a.q","a.q.","aq.","atkafası","atmık","avrat","babaannesikaşar","babanı","babanın","babani","babasıpezevenk","bacına","bacını","bacının","bacini","bacn","bacndan","bitch","bok","boka","bokbok","bokça","bokkkumu","boklar","boktan","boku","bokubokuna","bokum","bombok","boner","bosalmak","boşalmak","çük","dallama","daltassak","dalyarak","dalyarrak","dangalak","dassagi","diktim","dildo","dingil","dingilini","dinsiz","dkerim","domal","domalan","domaldı","domaldın","domalık","domalıyor","domalmak","domalmış","domalsın","domalt","domaltarak","domaltıp","domaltır","domaltırım","domaltip","domaltmak","dölü","eben","ebeni","ebenin","ebeninki","ecdadını","ecdadini","embesil","fahise","fahişe","feriştah","ferre","fuck","fucker","fuckin","fucking","gavad","gavat","geber","geberik","gebermek","gebermiş","gebertir","gerızekalı","gerizekalı","gerizekali","gerzek","gotlalesi","gotlu","gotten","gotundeki","gotunden","gotune","gotunu","gotveren","göt","götdeliği","götherif","götlalesi","götlek","götoğlanı","götoğlanı","götoş","götten","götü","götün","götüne","götünekoyim","götünekoyim","götünü","götveren","götveren","götverir","gtveren","hasiktir","hassikome","hassiktir","hassiktir","hassittir","ibine","ibinenin","ibne","ibnedir","ibneleri","ibnelik","ibnelri","ibneni","ibnenin","ibnesi","ipne","itoğluit","kahpe","kahpenin","kaka","kaltak","kancık","kancik","kappe","kavat","kavatn","kocagöt","koduğmunun","kodumun","kodumunun","koduumun","mal","malafat","malak","manyak","meme","memelerini","oc","ocuu","ocuun","0Ç","o.çocuğu","orosbucocuu","orospu","orospucocugu","orospuçoc","orospuçocuğu","orospuçocuğudur","orospuçocukları","orospudur","orospular","orospunun","orospununevladı","orospuydu","orospuyuz","orrospu","oruspu","oruspuçocuğu","oruspuçocuğu","osbir","öküz","penis","pezevek","pezeven","pezeveng","pezevengi","pezevenginevladı","pezevenk","pezo","pic","pici","picler","piç","piçinoğlu","piçkurusu","piçler","pipi","pisliktir","porno","pussy","puşt","puşttur","s1kerim","s1kerm","s1krm","sakso","salaak","salak","serefsiz","sexs","sıçarım","sıçtığım","sıkecem","sicarsin","sie","sik","sikdi","sikdiğim","sike","sikecem","sikem","siken","sikenin","siker","sikerim","sikerler","sikersin","sikertir","sikertmek","sikesen","sikey","sikeydim","sikeyim","sikeym","siki","sikicem","sikici","sikien","sikienler","sikiiim","sikiiimmm","sikiim","sikiir","sikiirken","sikik","sikil","sikildiini","sikilesice","sikilmi","sikilmie","sikilmis","sikilmiş","sikilsin","sikim","sikimde","sikimden","sikime","sikimi","sikimiin","sikimin","sikimle","sikimsonik","sikimtrak","sikin","sikinde","sikinden","sikine","sikini","sikip","sikis","sikisek","sikisen","sikish","sikismis","sikiş","sikişen","sikişme","sikitiin","sikiyim","sikiym","sikiyorum","sikkim","sikleri","sikleriii","sikli","sikm","sikmek","sikmem","sikmiler","sikmisligim","siksem","sikseydin","sikseyidin","siksin","siksinler","siksiz","siksok","siksz","sikti","siktigimin","siktigiminin","siktiğim","siktiğimin","siktiğiminin","siktii","siktiim","siktiimin","siktiiminin","siktiler","siktim","siktimin","siktiminin","siktir","siktiret","siktirgit","siktirgit","siktirir","siktiririm","siktiriyor","siktirlan","siktirolgit","sittimin","skcem","skecem","skem","sker","skerim","skerm","skeyim","skiim","skik","skim","skime","skmek","sksin","sksn","sksz","sktiimin","sktrr","skyim","slaleni","sokam","sokarım","sokarim","sokarm","sokarmkoduumun","sokayım","sokaym","sokiim","soktuğumunun","sokuk","sokum","sokuş","sokuyum","soxum","sulaleni","sülalenizi","tasak","tassak","taşak","taşşak","s.k","s.keyim","vajina","vajinanı","xikeyim","yaaraaa","yalarım","yalarun","orospi","orospinin","orospının","orospı","yaraaam","yarak","yaraksız","yaraktr","yaram","yaraminbasi","yaramn","yararmorospunun","yarra","yarraaaa","yarraak","yarraam","yarraamı","yarragi","yarragimi","yarragina","yarragindan","yarragm","yarrağ","yarrağım","yarrağımı","yarraimin","yarrak","yarram","yarramin","yarraminbaşı","yarramn","yarran","yarrana","yarrrak","yavak","yavş","yavşak","yavşaktır","yrrak","zigsin","zikeyim","zikiiim","zikiim","zikik","zikim","ziksiin","ağzına","mk","amcık","amcıkağız","amcıkları","amık","amın","amına","amınakoyim","amınoğlu","amina","amini","amk","amq","anan","ananı","ananızı","ananizi","aminizi","aminii","avradını","avradini","anasını","b.k","bok","boktan","boşluk","dalyarak","dasak","dassak","daşak","daşşak","daşşaksız","durum","ensest","erotik","fahişe","fuck","g*t","g*tü","g*tün","g*tüne","g.t","gavat","gay","gerızekalıdır","gerizekalı","gerizekalıdır","got","gotunu","gotuze","göt","götü","götüne","götünü","götünüze","götüyle","götveren","götvern","guat","hasiktir","hasiktr","hastir","i.ne","ibne","ibneler","ibneliği","ipne","ipneler","it","iti","itler","kavat","kıç","kıro","kromusunuz","kromusunuz","lezle","lezler","nah","o.ç","oç.","okuz","orosbu","orospu","orospucocugu","orospular","otusbir","otuzbir","öküz","penis","pezevenk","pezevenkler","pezo","pic","piç","piçi","piçinin","piçler","pis","pok","pokunu","porn","porno","puşt","sex","s.tir","sakso","salak","sanane","sanane","sçkik","seks","serefsiz","serefsz","serefszler","sex","sıçmak","sıkerım","sıkm","sıktır","si.çmak","sicmak","sicti","sik","sikenin","siker","sikerim","sikerler","sikert","sikertirler","sikertmek","sikeyim","sikicem","sikiim","sikik","sikim","sikime","sikimi","sikiş","sikişken","sikişmek","sikm","sikmeyi","siksinler","siktiğim","siktimin","siktin","siktirgit","siktir","siktirgit","siktirsin","siqem","skiym","skm","skrm","sktim","sktir","sktirsin","sktr","sktroradan","sktrsn","snane","sokacak","sokarim","sokayım","sülaleni","şerefsiz","şerefsizler","şerefsizlerin","şerefsizlik","tasak","tassak","taşak","taşşak","travesti","yarak","yark","yarrağım","yarrak","yarramın","yarrk","yavşak","yrak","yrk","ebenin","ezik","o.ç.","orospu","öküz","pezevenk","piç","puşt","salak","salak","serefsiz","sik","sperm","bok","aq","a.q.","amk","amına","ebenin","ezik","fahişe","gavat","gavurundölü","gerizekalı","göte","götü","götüne","götünü","lan","mal","o.ç.","orospu","pezevenk","piç","puşt","salak","salak","serefsiz","sik","sikkırığı","sikerler","sikertmek","sikik","sikilmiş","siktir","sperm","taşak","totoş","yarak","yarrak","bok","aq","a.q.","amk","ebenin","fahişe","gavat","gerizakalı","gerizekalı","göt","göte","götü","götüne","götsün","piçsin","götsünüz","piçsiniz","götünüze","kıçınız","kıçınıza","götünü","hayvan","ibne","ipne","kahpe","kaltak","lan","mal","o.c","oc","manyak","o.ç.","oç","orospu","öküz","pezevenk","piç","puşt","salak","serefsiz","sik","sikkırığı","sikerler","sikertmek","sikik","sikiim","siktim","siki","sikilmiş","siktir","siktir","sperm","şerefsiz","taşak","totoş","yarak","yarrak","yosma","aq","a.q.","amk","amına","amınakoyim","amina","ammına","amna","sikim","sikiym","sikeyim","siktr","kodumun","amık","sikem","sikim","sikiym","s.iktm","s.ikerim","s.ktir","amg","am.k","a.mk","amık","rakı","rak","oruspu","oc","ananın","ananınki","bacının","bacını","babanın","sike","skim","skem","amcık","şerefsiz","piç","piçinoğlu","amcıkhoşafı","amınasokam","amkçocuğu","amınferyadı","amınoglu","piçler","sikerim","sikeyim","siktiğim","siktiğimin","amını","amına","amınoğlu","amk","ipne","ibne","serefsiz","şerefsiz","piç","piçkurusu","götün","götoş","yarrak","amcik","sıçarım","sıçtığım","aq","a.q","a.q.","aq.","a.g.","ag.","amınak","aminak","amınag","aminag","amınıs","amınas","ananı","babanı","anani","babani","bacını","bacini","ecdadını","ecdadini","sikeyim","sulaleni","sülaleni","dallama","dangalak","aptal","salak","gerızekalı","gerizekali","öküz","angut","dalyarak","sikiyim","sikeyim","götüne","götünü","siktirgit","siktirgit","siktirolgit","siktirolgit","siktir","hasiktir","hassiktir","hassiktir","dalyarak","dalyarrak","kancık","kancik","kaltak","orospu","oruspu","fahişe","fahise","pezevenk","pezo","kocagöt","ambiti","götünekoyim","götünekoyim","amınakoyim","aminakoyim","amınak","aminakoyayım","aminakoyayim","amınakoyarım","aminakoyarim","aminakoyarim","ananısikeyim","ananisikeyim","ananısikeyim","ananisikeyim","ananisikerim","ananısikerim","ananisikerim","ananısikerim","orospucocugu","oruspucocu","amk","amq","sikik","götveren","götveren","amınoğlu","aminoglu","amınoglu","gavat","kavat","anneni","annenin","ananın","ananin","dalyarak","sikik","amcık","siktir","piç","pic","sie","yarram","göt","meme","dildo","skcem","skerm","skerim","skecem","orrospu","annesiz","kahpe","kappe","yarak","yaram","dalaksız","yaraksız","amlı","s1kerim","s1kerm","s1krm","sikim","orospuçocukları", "oç"];
    const uyarılar = [
    '**Hey hey hey bunu yapma!**',
    '**Çok ayıp çooook görmiyim bida!**',
    '**Sen ahlaksız çocuk olmuşsun!**',
    '**Hey kendine gel bunu yapma!**'];
    let uyarımesaj = uyarılar[Math.floor(Math.random() * uyarılar.length)];
    if(blacklist.some(word => message.content.toLowerCase().includes(word))) {
    if(message.member.permissions.has('BAN_MEMBERS')) return;
    newMessage.delete();
    message.channel.send(new Discord.MessageEmbed().setColor("#000000").setTitle('Küfür Kısıtlı').setDescription(`${message.author} ${uyarımesaj}`)).then(a => a.delete({timeout: 5000}));
}
})

//--------------- Reklam Koruması ----------------//

client.on('message', async message => {
  const reklam = await db.fetch(`reklam.${message.guild.id}`);
  if(!reklam) return;
  const blacklist = [".com", ".net", ".xyz", ".tk", ".pw", ".io", ".me", ".gg", "www.", "https", "http", ".gl", ".org", ".com.tr", ".biz", "net", ".rf.gd", ".az", ".party", "discord.gg"];
  const uyarılar = [
   '**Hey hey hey bunu yapma!**',
   '**Sakın bunu bida yapma!**',
   '**Kendine gel yada defol sunucudan!**'];
   let uyarımesaj = uyarılar[Math.floor(Math.random() * uyarılar.length)];
   if(blacklist.some(a => message.content.includes(a)))  {
   if(message.member.permissions.has('BAN_MEMBERS')) return;
   message.delete();
   message.channel.send(new Discord.MessageEmbed().setColor("#000000").setTitle('Reklam Kısıtlı').setDescription(`${message.author} ${uyarımesaj}`)).then(a => a.delete({timeout: 5000}));
}
});

client.on('messageUpdate', async (newMessage, message) => {
  const reklam = await db.fetch(`reklam.${message.guild.id}`);
  if(!reklam) return;
  const blacklist = [".com", ".net", ".xyz", ".tk", ".pw", ".io", ".me", ".gg", "www.", "https", "http", ".gl", ".org", ".com.tr", ".biz", "net", ".rf.gd", ".az", ".party", "discord.gg"];
  const uyarılar = [
  '**Hey hey hey bunu yapma!**',
  '**Sakın bunu bida yapma!**',
  '**Kendine gel yada defol sunucudan!**'];
  let uyarımesaj = uyarılar[Math.floor(Math.random() * uyarılar.length)];
  if(blacklist.some(a => message.content.includes(a)))  {
  if(message.member.permissions.has('BAN_MEMBERS')) return;
  newMessage.delete();
  message.channel.send(new Discord.MessageEmbed().setColor("#000000").setTitle('Reklam Kısıtlı').setDescription(`${message.author} ${uyarımesaj}`)).then(a => a.delete({timeout: 5000}));
}
})

//--------------- Spam Koruması ----------------//

//--------------- Caps Koruması ----------------//

client.on('message', async message => {
  if(message.channel.type !== 'text') return;
  if(message.content.length >= 5) {
  const caps = await db.fetch(`caps.${message.guild.id}`);
  if(!caps) return;
  let kontrol = message.content.toUpperCase()
  if(message.content === kontrol) {
  if(message.member.permissions.has('BAN_MEMBERS')) return;
  if(message.mentions.users.first()) return;
  return message.delete();
}}});

//--------------- Patlatma Koruma Sistemi ----------------//

client.on("guildBanAdd", async(guild, user) => {

  const kanal = db.fetch(`bankoruma_${guild.id}`); 
  if (!kanal) return;

  let banlimit = await db.fetch(`banlimit_${guild.id}`)
  if (!banlimit) return;

  const entry = await guild.fetchAuditLogs({ type: "MEMBER_BAN_ADD" }).then(audit => audit.entries.first());
  let kullanılanlimit = await db.fetch(`bankullanici_${entry.executor.id}`)

  await db.add(`bankullanici_${entry.executor.id}`, 1)
        
  const embed = new Discord.MessageEmbed()
  .setAuthor(`${ayarlar.botisim}`, client.user.avatarURL())
  .setColor("#000000")
  .setTitle(`Birisi Yasaklandı!`)
  .addField(`Yasaklayan`, `<@${entry.executor.id}>`)
  .addField(`Yasaklanan Kişi`, `<@${user.id}>`)
  .addField("Yasaklanma Sebebi", `${entry.reason ? entry.reason : "\`sebep girilmedi\`"}`)
  .addField(`Sonuç`,`\`Üye sunucudan yasaklandı, yetkilinin kalan limiti ${kullanılanlimit ? kullanılanlimit : "0"}/${banlimit}\``)
  .setFooter(`${ayarlar.botisim} | Koruma Sistemi`, client.user.avatarURL())
  .setTimestamp();
  client.channels.cache.get(kanal).send(embed);  

  if(kullanılanlimit >= banlimit) {
   let yetkili = guild.members.cache.get(entry.executor.id);
   yetkili.roles.cache.forEach(rol => {
   if(rol.permissions.has('BAN_MEMBERS')) return yetkili.roles.remove(rol.id);
   if(rol.permissions.has('ADMINISTRATOR')) return yetkili.roles.remove(rol.id);

   const embed = new Discord.MessageEmbed()
   .setAuthor(`${ayarlar.botisim}`, client.user.avatarURL())
   .setColor("#000000")
   .setTitle(`Yasaklama Sınırı Aşıldı!`)
   .addField(`Yasaklayan`, `<@${entry.executor.id}>`)
   .addField(`Yasaklanmaya Çalışılan Kişi`, `<@${user.id}>`)
   .addField("Yasaklanma Sebebi", `${entry.reason ? entry.reason : "\`sebep girilmedi\`"}`)
   .addField(`Sonuç`,`\`Yasaklama Yapmaya çalışan kişinin yetkisi alındı!\``)
   .setFooter(`${ayarlar.botisim} | Koruma Sistemi`, client.user.avatarURL())
   .setTimestamp();
   client.channels.cache.get(kanal).send(embed);

   db.delete(`bankullanici_${entry.executor.id}`)
  })
}
})

client.on("roleDelete", async role => {
  let kanal = await db.fetch(`rolkoruma_${role.guild.id}`);
  if (!kanal) return;

  const entry = await role.guild.fetchAuditLogs({ type: "ROLE_DELETE" }).then(audit => audit.entries.first());
  
  if (entry.executor.id == client.user.id) return;
  if (entry.executor.id == role.guild.owner.id) return;

  role.guild.roles.create({ data: {
    name: role.name,
    color: role.color,
    hoist: role.hoist,
    permissions: role.permissions,
    mentionable: role.mentionable,
    position: role.position
}, reason: 'Silinen Rol Açıldı.'}).then(r => r.setPosition(role.position));

      const embed = new Discord.MessageEmbed()
      .setAuthor(`${ayarlar.botisim}`, client.user.avatarURL())
      .setColor("#000000")
      .setTitle(`Bir Rol Silindi!`)
      .addField(`Silen Yetkili`, `<@${entry.executor.id}>`)
      .addField(`Silinen Rol`, `\`${role.name}\``)
      .addField(`Sonuç`, `\`Rol Geri Açıldı!\``)
      .setFooter(`${ayarlar.botisim} | Koruma Sistemi`, client.user.avatarURL())
      .setTimestamp();
      client.channels.cache.get(kanal).send(embed);
});

client.on("roleCreate", async role => {
  let kanal = await db.fetch(`rolkoruma_${role.guild.id}`);
  if (!kanal) return;

  const entry = await role.guild.fetchAuditLogs({ type: "ROLE_CREATE" }).then(audit => audit.entries.first());

  if (entry.executor.id == client.user.id) return;
  if (entry.executor.id == role.guild.owner.id) return;

      role.delete();

      const embed = new Discord.MessageEmbed()
      .setAuthor(`${ayarlar.botisim}`, client.user.avatarURL())
      .setColor("#000000")
      .setTitle(`Bir Rol Açıldı!`)
      .addField(`Açan Yetkili`, `<@${entry.executor.id}>`)
      .addField(`Açılan Rol`, `\`${role.name}\``)
      .addField(`Sonuç`, `\`Rol Geri Silindi!\``)
      .setFooter(`${ayarlar.botisim} | Koruma Sistemi`, client.user.avatarURL())
      .setTimestamp();
      client.channels.cache.get(kanal).send(embed);
});

client.on("channelDelete", async channel => {
  let kanal = await db.fetch(`kanalkoruma_${channel.guild.id}`);
  if (!kanal) return;

    const entry = await channel.guild.fetchAuditLogs({ type: "CHANNEL_DELETE" }).then(audit => audit.entries.first());

    if (entry.executor.id == client.user.id) return;
    if (entry.executor.id == channel.guild.owner.id) return;

    channel.clone({ name: channel.name });

    const embed = new Discord.MessageEmbed()
    .setAuthor(`${ayarlar.botisim}`, client.user.avatarURL())
    .setColor("#000000")
    .setTitle(`Bir Kanal Silindi!`)
    .addField(`Silen Yetkili`, `<@${entry.executor.id}>`)
    .addField(`Silinen Kanal`, `\`${channel.name}\``)
    .addField(`Sonuç:`, `\`Kanal Geri Açıldı!\``)
    .setFooter(`${ayarlar.botisim} | Koruma Sistemi`, client.user.avatarURL())
    .setTimestamp();
    client.channels.cache.get(kanal).send(embed);
});

client.on("channelCreate", async channel => {
  let kanal = await db.fetch(`kanalkoruma_${channel.guild.id}`);
  if (!kanal) return;

    const entry = await channel.guild.fetchAuditLogs({ type: "CHANNEL_CREATE" }).then(audit => audit.entries.first());
    
    if (entry.executor.id == client.user.id) return;
    if (entry.executor.id == channel.guild.owner.id) return;

    channel.delete();
    
    const embed = new Discord.MessageEmbed()
    .setAuthor(`${ayarlar.botisim}`, client.user.avatarURL())
    .setColor("#000000")
    .setTitle(`Bir Kanal Açıldı!`)
    .addField(`Açan Yetkili`, `<@${entry.executor.id}>`)
    .addField(`Açılan Kanal`, `\`${channel.name}\``)
    .addField(`Sonuç:`, `\`Kanal Geri Silindi!\``)
    .setFooter(`${ayarlar.botisim} | Koruma Sistemi`, client.user.avatarURL())
    .setTimestamp();
    client.channels.cache.get(kanal).send(embed);
});

//----------------- ModLog ------------------\\

client.on("messageDelete", async message => {
  if (message.author.bot || message.channel.type == "dm") return;
  let modlog = await db.fetch(`log_${message.guild.id}`);
  if (!modlog) return;

  let embed = new Discord.MessageEmbed()
    .setAuthor(`${ayarlar.botisim}`, client.user.avatarURL())
    .setColor("#000000")
    .addField("Eylem", "\`Mesaj Silme\`")
    .addField("Mesaj Sahibi", `${message.author}`)
    .addField("Kanal", `${message.channel}`)
    .addField("Silinen Mesaj", `\`${message.content}\``)
    .setFooter(`${ayarlar.botisim} | ModLog Sistemi`, client.user.avatarURL())
    .setTimestamp();
  client.channels.cache.get(modlog).send(embed);
});

client.on("messageUpdate", async (oldMessage, newMessage) => {
  let modlog = await db.fetch(`log_${oldMessage.guild.id}`);
  if (!modlog) return;

  let embed = new Discord.MessageEmbed()
    .setAuthor(`${ayarlar.botisim}`, client.user.avatarURL())
    .setColor("#000000")
    .addField("Eylem", "\`Mesaj Düzenleme\`")
    .addField("Mesajın Sahibi",`${oldMessage.author}`)
    .addField("Kanal", `${newMessage.channel}`)
    .addField("Eski Mesajı", `\`${oldMessage.content}\``)
    .addField("Yeni Mesajı", `\`${newMessage.content}\``)
    .setFooter(`${ayarlar.botisim} | ModLog Sistemi`, client.user.avatarURL())
    .setTimestamp();
  client.channels.cache.get(modlog).send(embed);
});

client.on("channelCreate", async channel => {
  let modlog = await db.fetch(`log_${channel.guild.id}`);
  if (!modlog) return;

  const entry = await channel.guild.fetchAuditLogs({ type: "CHANNEL_CREATE" }).then(audit => audit.entries.first());
  if (entry.executor.id == client.user.id) return;

  let embed = new Discord.MessageEmbed()
    .setAuthor(`${ayarlar.botisim}`, client.user.avatarURL())
    .setColor("#000000")
    .addField("Eylem", "\`Kanal Oluşturma\`")
    .addField("Kanalı Oluşturan Kişi", `<@${entry.executor.id}>`)
    .addField("Oluşturulan Kanal", `\`${channel.name}\``)
    .setFooter(`${ayarlar.botisim} | ModLog Sistemi`, client.user.avatarURL())
    .setTimestamp();
  client.channels.cache.get(modlog).send(embed);
});

client.on("channelDelete", async channel => {
  let modlog = await db.fetch(`log_${channel.guild.id}`);
  if (!modlog) return;

  const entry = await channel.guild.fetchAuditLogs({ type: "CHANNEL_DELETE" }).then(audit => audit.entries.first());
  if (entry.executor.id == client.user.id) return;

  let embed = new Discord.MessageEmbed()
    .setAuthor(`${ayarlar.botisim}`, client.user.avatarURL())
    .addField("Eylem", "\`Kanal Silme\`")
    .addField("Kanalı Silen Kişi", `<@${entry.executor.id}>`)
    .addField("Silinen Kanal", `\`${channel.name}\``)
    .setColor("#000000")
    .setFooter(`${ayarlar.botisim} | ModLog Sistemi`, client.user.avatarURL())
    .setTimestamp();
  client.channels.cache.get(modlog).send(embed);
});

client.on("roleCreate", async role => {
  let modlog = await db.fetch(`log_${role.guild.id}`);
  if (!modlog) return;

  const entry = await role.guild.fetchAuditLogs({ type: "ROLE_CREATE" }).then(audit => audit.entries.first());
  if (entry.executor.id == client.user.id) return;

  let embed = new Discord.MessageEmbed()
    .setAuthor(`${ayarlar.botisim}`, client.user.avatarURL())
    .setColor("#000000")
    .addField("Eylem", "\`Rol Oluşturma\`")
    .addField("Rolü Oluşturan Kişi", `<@${entry.executor.id}>`)
    .addField("Oluşturulan Rol Ad ve ID", `\`${role.name}\` **-** \`${role.id}\``)
    .setFooter(`${ayarlar.botisim} | ModLog Sistemi`, client.user.avatarURL())
    .setTimestamp();
  client.channels.cache.get(modlog).send(embed);
});

client.on("roleDelete", async role => {
  let modlog = await db.fetch(`log_${role.guild.id}`);
  if (!modlog) return;

  const entry = await role.guild.fetchAuditLogs({ type: "ROLE_DELETE" }).then(audit => audit.entries.first());
  if (entry.executor.id == client.user.id) return;

  let embed = new Discord.MessageEmbed()
  .setAuthor(`${ayarlar.botisim}`, client.user.avatarURL())
    .setColor("#000000")
    .addField("Eylem", "\`Rol Silme\`")
    .addField("Rolü Silen Kişi", `<@${entry.executor.id}>`)
    .addField("Silinen Rol Ad ve ID", `\`${role.name}\` **-** \`${role.id}\``)
    .setFooter(`${ayarlar.botisim} | ModLog Sistemi`, client.user.avatarURL())
    .setTimestamp();
  client.channels.cache.get(modlog).send(embed);
});

client.on("emojiCreate", async emoji => {
  let modlog = await db.fetch(`log_${emoji.guild.id}`);
  if (!modlog) return;

  const entry = await emoji.guild.fetchAuditLogs({ type: "EMOJI_CREATE" }).then(audit => audit.entries.first());
  if (entry.executor.id == client.user.id) return;

  let embed = new Discord.MessageEmbed()
    .setAuthor(`${ayarlar.botisim}`, client.user.avatarURL())
    .setColor("#000000")
    .addField("Eylem", "\`Emoji Oluşturma\`")
    .addField("Oluşturan Kişi", `<@${entry.executor.id}>`)
    .addField("Oluşturulan Emoji", `${emoji} \`${emoji.name}\``)
    .setFooter(`${ayarlar.botisim} | ModLog Sistemi`, client.user.avatarURL())
    .setTimestamp();
  client.channels.cache.get(modlog).send(embed);
});

client.on("emojiDelete", async emoji => {
  let modlog = await db.fetch(`log_${emoji.guild.id}`);
  if (!modlog) return;

  const entry = await emoji.guild.fetchAuditLogs({ type: "EMOJI_DELETE" }).then(audit => audit.entries.first());
  if (entry.executor.id == client.user.id) return;

  let embed = new Discord.MessageEmbed()
    .setAuthor(`${ayarlar.botisim}`, client.user.avatarURL())
    .setColor("#000000")
    .addField("Eylem:", "\`Emoji Silme\`")
    .addField("Silen Kişi", `<@${entry.executor.id}>`)
    .addField("Silinen Emoji", `\`${emoji}\``)
    .setFooter(`${ayarlar.botisim} | ModLog Sistemi`, client.user.avatarURL())
    .setTimestamp();
  client.channels.cache.get(modlog).send(embed);
});

client.on("emojiUpdate", async (oldEmoji, newEmoji) => {
  let modlog = await db.fetch(`log_${oldEmoji.guild.id}`);
  if (!modlog) return;

  const entry = await oldEmoji.guild.fetchAuditLogs({ type: "EMOJI_UPDATE" }).then(audit => audit.entries.first());
  if (entry.executor.id == client.user.id) return;

  let embed = new Discord.MessageEmbed()
    .setAuthor(`${ayarlar.botisim}`, client.user.avatarURL())
    .setColor("#000000")
    .addField("Eylem:", "\`Emoji Güncelleme\`")
    .addField("Güncelleyen Kişi", `<@${entry.executor.id}>`)
    .addField("Önceki Emoji Adı",`${oldEmoji} \`${oldEmoji.name}\``)
    .addField("Yeni Emoji Adı",`${newEmoji} \`${newEmoji.name}\``)
    .setFooter(`${ayarlar.botisim} | ModLog Sistemi`, client.user.avatarURL())
    .setTimestamp();
  client.channels.cache.get(modlog).send(embed);
});

client.on("guildBanAdd", async (guild, user) => {
  let modlog = await db.fetch(`log_${guild.id}`);
  if (!modlog) return;

  const entry = await guild.fetchAuditLogs({ type: "MEMBER_BAN_ADD" }).then(audit => audit.entries.first());
  let embed = new Discord.MessageEmbed()
    .setAuthor(`${ayarlar.botisim}`, client.user.avatarURL())
    .setColor("#000000")
    .addField("Eylem", "\`Yasaklama\`")
    .addField("Kullanıcıyı Yasaklayan Yetkili", `<@${entry.executor.id}>`)
    .addField("Yasaklanan Kullanıcı", `<@${user.id}>`)
    .addField("Yasaklanma Sebebi", `${entry.reason ? entry.reason : "\`sebep girilmedi\`"}`)
    .setFooter(`${ayarlar.botisim} | ModLog Sistemi`, client.user.avatarURL())
    .setTimestamp();
  client.channels.cache.get(modlog).send(embed);
});

client.on("guildBanRemove", async (guild, user) => {
  let modlog = await db.fetch(`log_${guild.id}`);
  if (!modlog) return;
  
  const entry = await guild.fetchAuditLogs({ type: "MEMBER_BAN_REMOVE" }).then(audit => audit.entries.first());
  let embed = new Discord.MessageEmbed()
    .setAuthor(`${ayarlar.botisim}`, client.user.avatarURL())
    .setColor("#000000")
    .addField("Eylem", "\`Yasak Kaldırma\`")
    .addField("Yasağı Kaldıran Yetkili", `<@${entry.executor.id}>`)
    .addField("Yasağı Kaldırılan Kullanıcı",`<@${user.id}>`)
    .setFooter(`${ayarlar.botisim} | ModLog Sistemi`, client.user.avatarURL())
    .setTimestamp();
  client.channels.cache.get(modlog).send(embed);
});

//Müzik Komutu