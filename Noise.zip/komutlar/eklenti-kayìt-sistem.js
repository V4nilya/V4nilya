const Discord = require(`discord.js`);
const db = require(`quick.db`);
const ayarlar = require("../ayarlar/bot.json");

exports.run = async (client, message, args) => { 
let prefix = db.fetch(`prefix.${message.guild.id}`) || ayarlar.prefix 
const embed = new Discord.MessageEmbed()  
.setColor(`#000000`)
.setAuthor(`${ayarlar.botisim}${ayarlar.isim_eki} rolünü yukarıda tutmayı unutmayın!`, client.user.avatarURL())
.setDescription(`
\`\`\`                    [ Kurulum Komutları ]           \`\`\`
${ayarlar.vanilya} \`${prefix}erkek-rol @rol\`
**Erkek üyelere verilecek rolü ayarlarsın!**

${ayarlar.vanilya} \`${prefix}kadın-rol @rol\`
**Kadın üyelere verilecek rolü ayarlarsın!**

${ayarlar.vanilya} \`${prefix}kayıt-yetkili-rol @rol\`
**Kayıt yetkilisi rolüdür \`${prefix}erkek\`,\`${prefix}kadın\` ve \`${prefix}kayıt-stats\` komutlarını kullanma yetkisi tanır!**

${ayarlar.vanilya} \`${prefix}kayıtsız-rol @rol\`
**Sunucuya yeni giren insanlara otomatik verilen roldür! \`otorol-sistem'ini\` kapatmayı unutmayın!**

${ayarlar.vanilya} \`${prefix}kayıt-kanal\`
**Üyelerin giriş yaptığında karşılama mesajı alacağı kanaldır 
ve sadece bu kanalda kayıt komutları kullanılabilir.**

${ayarlar.vanilya} \`${prefix}kayıt-tag\`
**İsterseniz Üyeleri kayıt ederken isimlerinin başına otomatik tag koyabilirsiniz.**

\`\`\`                    [ Kullanım Komutları ]            \`\`\`
${ayarlar.vanilya} \`${prefix}erkek @üye\`
**Kayıtsız rolünü alıp erkek rolünü verir.**

${ayarlar.vanilya} \`${prefix}kadın @üye\`
**Kayıtsız rolünü alıp kadın rolünü verir.**

${ayarlar.vanilya} \`${prefix}kayıt-stats\`
**Kayıt İstatistiğini gösterir üyenin \`Kayıt-Yetkilisi\` rolü olması gerekir.**

\`\`\`                   [ Sıfırlama Komutları ]           \`\`\`
${ayarlar.vanilya} \`${prefix}erkek-rol sıfırla\`
**Erkek rolünü sıfırlar!**

${ayarlar.vanilya} \`${prefix}kadın-rol sıfırla\`
**Kadın rolünü sıfırlar!**

${ayarlar.vanilya} \`${prefix}yetkili-rol sıfırla\`
**Yetkili rolünü sıfırlar!**

${ayarlar.vanilya} \`${prefix}kayıtsız-rol sıfırla\`
**Kayıtsız rolünü sıfırlar!**`)
.setTimestamp()
.setFooter(`${message.author.username} tarafından kullanıldı`, client.user.avatarURL())
return message.channel.send(embed).then(a => a.delete({timeout: 150000}));
};

exports.config = {
  name: "kayıt-sistem",
    aliases: []
  }