const Discord = require("discord.js")
const db = require('quick.db')
const ayarlar = require("../ayarlar/bot.json");

exports.run = async(client, message, args) => {
let prefix = await db.fetch(`prefix.${message.guild.id}`) || ayarlar.prefix 

if(!message.member.permissions.has(`ADMINISTRATOR`)) return message.channel.send(new Discord.MessageEmbed().setColor("#000000").setTitle(`Bir hata oldu!`).setDescription(`${ayarlar.vanilya} **Bu komutu kullanabilmek için \`Yönetici\` yetkisine ihtiyacın var.**`)).then(m => m.delete({timeout: 10000}));
let mentionEmbed = new Discord.MessageEmbed().setColor('#000000').setTitle('Bir hata oldu!').setDescription(`**${ayarlar.vanilya} Önce \`komutun\` sonrasında \`cevabın\` ayarlanması gerek!**

**Örnek kullanım:**
\`\`\`${prefix}otocevap-3 nasılsın iyiyim\`\`\``)


if (!args[0]) return message.channel.send(mentionEmbed)
if (!args[1]) return message.channel.send(mentionEmbed) 
                
let komut;
if (!args[0]) komut = ''; 
else komut = (args[0]); 
if(args[0] == 'yardım') return message.channel.send('Bu komutu sunucuna özel cevap olarak ekleyemezsin.')                   
let gonderileceksey;
if (args.slice(1, 1000, args[1]).join(' ') === 'NONE') gonderileceksey = ''; 
else gonderileceksey = args.slice(1, 1000, args[1]).join(' '); 
                
let embed = new Discord.MessageEmbed()
.setTitle(`İşte bu kadar!`).setColor('#000000').setDescription(`**${ayarlar.vanilya} Sunucuna özel komut eklendi.

\`${komut}\` yazıldığı zaman \`${gonderileceksey}\` olarak yanıt vereceğim. ${ayarlar.onayla}**`)
db.set(`sunucuKomut3_${message.guild.id}`, komut)
db.set(`sunucuMesaj3_${message.guild.id}`, gonderileceksey)
return message.channel.send(embed) 
};

exports.config = {
name: "otocevap-3",
  aliases: []
}
