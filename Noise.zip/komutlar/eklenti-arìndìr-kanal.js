const Discord = require(`discord.js`);
const db = require(`quick.db`);
const ayarlar = require("../ayarlar/bot.json");

exports.run = async (client, message, args) => {
let prefix = await db.fetch(`prefix.${message.guild.id}`) || ayarlar.prefix 
if(message.author.id !== message.guild.owner.user.id) return message.channel.send(new Discord.MessageEmbed().setColor("#000000").setTitle(`Bir hata oldu!`).setDescription(`${ayarlar.vanilya} **Bu komutu kullanabilmek için \`Sunucu Sahibi\` olmalısın.**`)).then(m => m.delete({timeout: 10000}));
message.channel.send(new Discord.MessageEmbed()
.setColor("#000000")
.setTitle(`Dikkatli ol!`)
.setTimestamp()
.setFooter(`${message.author.username} tarafından kullanıldı`, client.user.avatarURL())
.setDescription(`${message.author} **Sunucunun \`Kanallarını\` silmek istediğine emin misin?**

**Bu işlem geri alınamaz**!`)).then(resulter => {
resulter.react(`✅`).then(() => resulter.react(`❌`));

const yesFilter = (reaction, user) => { return reaction.emoji.name === `✅` && user.id === message.guild.owner.user.id; };
const yes = resulter.createReactionCollector(yesFilter, { time: 0 });
const noFilter = (reaction, user) => { return reaction.emoji.name === `❌` && user.id === message.guild.owner.user.id; };
const no = resulter.createReactionCollector(noFilter, { time: 0 });

yes.on(`collect`, async reaction => {
await message.guild.channels.cache.forEach(channel => channel.delete());
message.guild.channels.create(`embed`, { type: `text`}).then(m => {
	
const embed = new Discord.MessageEmbed()  
.setColor("#000000")
.setTitle(`İşte bu kadar!`)
.setDescription(`${ayarlar.vanilya} ${message.author} **Sunucunun kanallarını sıfırladı!**`)
.setFooter(`${message.author.username} tarafından kullanıldı`, client.user.avatarURL())
return message.channel.send(embed).then(a => a.delete({timeout: 150000}));
})
});

no.on(`collect`, async reaction => {
resulter.delete();
});

})
};

exports.config = {
  name: "kanal-arındır",
    aliases: []
}