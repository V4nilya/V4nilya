const db = require("quick.db");
const Discord = require('discord.js');
const ayarlar = require("../ayarlar/bot.json");

exports.run = async (client, message, args) => { 
let prefix = await db.fetch(`prefix.${message.guild.id}`) || ayarlar.prefix 

let eklenti = new Discord.MessageEmbed() 
.setAuthor(`${ayarlar.botisim}${ayarlar.isim_eki} rolünü yukarıda tutmayı unutmayın!`, client.user.avatarURL())
.setColor('#000000')
.setDescription(`\`\`\`                   [ Koruma Menüsü ]             \`\`\`
${ayarlar.vanilya} \`${prefix}küfür\` *[Yönetici]*
**Sunucuda küfür edilmesini engeller.**

${ayarlar.vanilya} \`${prefix}reklam\` *[Yönetici]*
**Sunucuda reklam yapılmasını engeller.**

${ayarlar.vanilya} \`${prefix}caps\` *[Yönetici]*
**Sunucuda büyük harf ile kelime yazılmasını engeller.**

${ayarlar.vanilya} \`${prefix}modlog\` *[Yönetici]*
**Sunucudaki mesaj, kanal, rol, ban ve emoji eylemlerini kaydeder.**

${ayarlar.vanilya} \`${prefix}anti-raid\` *[Sunucu Sahibi]*
**Olurda sunucunuz gece patlatılmaya çalışılırsa bu komut sizin için burada!**`)
.setTimestamp()
.setFooter(`${message.author.username} tarafından kullanıldı`, client.user.avatarURL())
return message.channel.send(eklenti).then(a => a.delete({timeout: 50000}));
};

exports.config = {
name: "koruma",
  aliases: []
}

