const Discord = require(`discord.js`);
const db = require(`quick.db`);
const ayarlar = require("../ayarlar/bot.json");

exports.run = async (client, message, args) => {
let prefix = await db.fetch(`prefix.${message.guild.id}`) || ayarlar.prefix 
const embed = new Discord.MessageEmbed()  
.setColor(`#000000`)
.setAuthor(`${ayarlar.botisim}'ın rolünü yukarıda tutmayı unutmayın!`, client.user.avatarURL())
.setDescription(`
\`\`\`                 [ Kullanım ]                 \`\`\`
${ayarlar.vanilya} \`${prefix}rol-arındır\`
**Tüm \`Rolleri\` kolayca silebilirsin.**

${ayarlar.vanilya} \`${prefix}kanal-arındır\`
**Tüm \`Kanalları\` kolayca silebilirsin.**`)
.setTimestamp()
.setFooter(`${message.author.username} tarafından kullanıldı`, client.user.avatarURL())
return message.channel.send(embed).then(a => a.delete({timeout: 150000}));
};

exports.config = {
  name: "arındır-sistem",
    aliases: []
}