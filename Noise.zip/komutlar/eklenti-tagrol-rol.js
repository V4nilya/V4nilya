const Discord = require(`discord.js`);
const db = require(`quick.db`);
const ayarlar = require("../ayarlar/bot.json");

exports.run = async (client, message, args) => {
  let prefix = db.fetch(`prefix.${message.guild.id}`) || ayarlar.prefix 
  if(!message.member.permissions.has(`ADMINISTRATOR`)) return message.channel.send(new Discord.MessageEmbed().setColor("#000000").setTitle(`Bir hata oldu!`).setDescription(`${ayarlar.vanilya} **Bu komutu kullanabilmek için \`Yönetici\` yetkisine ihtiyacın var.**`)).then(m => m.delete({timeout: 10000}));

if(args[0] === `sil`) {
db.delete(`tagrol.rol.${message.guild.id}`);
return message.channel.send(new Discord.MessageEmbed().setColor(`#00000`).setTitle(`İşte bu kadar!`).setDescription(`**${ayarlar.onayla} \`tagrol\` sistemi başarıyla kapatıldı!**`)).then(a => a.delete({timeout: 35000}));

} else {
if(!message.mentions.roles.first()) return message.channel.send(new Discord.MessageEmbed().setColor(`#00000`).setTitle(`Bir hata oldu!`).setDescription(`**${ayarlar.vanilya} Bir rol etiketlemelisin!**`)).then(a => a.delete({timeout: 35000}));
let mentionRole = message.mentions.roles.first();
db.set(`tagrol.rol.${message.guild.id}`, mentionRole.id);
return message.channel.send(new Discord.MessageEmbed().setColor(`#00000`).setTitle(`İşte bu kadar!`).setDescription(`${ayarlar.onayla} **Tagı alana verilecek rol ${mentionRole} olarak ayarlandı.**`)).then(a => a.delete({timeout: 35000}));
}
};

exports.config = {
  name: "tagrol-rol",
    aliases: []
  }