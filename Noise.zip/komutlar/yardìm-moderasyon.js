const db = require("quick.db");
const Discord = require('discord.js');
const ayarlar = require("../ayarlar/bot.json");

exports.run = async (client, message, args) => { 
let prefix = await db.fetch(`prefix.${message.guild.id}`) || ayarlar.prefix 

let vanitas = new Discord.MessageEmbed() 
.setColor('#000000') 
.setAuthor(`${ayarlar.botisim}${ayarlar.isim_eki} rolünü yukarıda tutmayı unutmayın!`, client.user.avatarURL())
.setDescription(`\`\`\`               [ Moderasyon Menüsü ]               \`\`\`
${ayarlar.vanilya} \`${prefix}sil\` *[Mesajları Yönet]*
**İstediğin kadar mesajı siler.**

${ayarlar.vanilya} \`${prefix}yavaş-mod\` *[Mesajları Yönet]*
**Art arda yazmak için bekleme süresi ayarlar.**

${ayarlar.vanilya} \`${prefix}jail\` *[Jail-Yetkili-Rolü]*
**Jail sistemini kullanabilmek için jail-sisteminin kurulumunun**
**yapılması gerekli. Kurulum için \`${prefix}jail-sistem\`**

${ayarlar.vanilya} \`${prefix}mute\` *[Mute-Chat-Yetkili-Rolü]*
**Mute sistemini kullanabilmek için mute-sisteminin kurulumunun**
**yapılması gerekli. Kurulum için \`${prefix}mute-sistem\`**

${ayarlar.vanilya} \`${prefix}mute-ses\` *[Mute-Ses-Yetkili-Rolü]*
**Mute sistemini kullanabilmek için mute-sisteminin kurulumunun**
**yapılması gerekli. Kurulum için \`${prefix}mute-sistem\`**

`)
.setTimestamp()
.setFooter(`${message.author.username} tarafından kullanıldı`, client.user.avatarURL())
return message.channel.send(vanitas).then(a => a.delete({timeout: 50000}));
};

exports.config = {
name: "moderasyon",
  aliases: []
}
