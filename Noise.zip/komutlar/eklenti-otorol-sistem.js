const Discord = require(`discord.js`);
const db = require(`quick.db`)
const ayarlar = require("../ayarlar/bot.json");

exports.run = async (client, message, args) => { 
let prefix = db.fetch(`prefix.${message.guild.id}`) || ayarlar.prefix 
const vanitas = new Discord.MessageEmbed()  
.setColor(`#000000`)
.setAuthor(`Vanitas'ın rolünü yukarıda tutmayı unutmayın!`, client.user.avatarURL())
.setDescription(`
\`\`\`                  [ Kullanım ]                   \`\`\`
${ayarlar.vanilya} \`${prefix}otorol @rol\`
**Otorol sistemini aktif edersin!**

${ayarlar.vanilya} \`${prefix}otorol kapat\`
**Otorol sistemini kapatır.**`)
.setTimestamp()
.setFooter(`${message.author.username} tarafından kullanıldı`, client.user.avatarURL())
return message.channel.send(vanitas).then(a => a.delete({timeout: 150000}));
};

exports.config = {
  name: "otorol-sistem",
    aliases: []
  }