const Discord = require(`discord.js`);
const db = require(`quick.db`)
const ayarlar = require("../ayarlar/bot.json");

exports.run = (client, message, args) => { 
const vanitas = new Discord.MessageEmbed()
let rol = message.mentions.roles.first() 
if(!message.member.permissions.has(`ADMINISTRATOR`)) return message.channel.send(new Discord.MessageEmbed().setColor("#000000").setTitle(`Bir hata oldu!`).setDescription(`${ayarlar.vanilya} **Bu komutu kullanabilmek için \`Yönetici\` yetkisine ihtiyacın var.**`)).then(m => m.delete({timeout: 10000})); 

if(args[0] === `kapat`) {
  const rol = db.fetch(`otoRL_${message.guild.id}`)  
  if(!rol) return message.reply(vanitas.setColor("#000000").setTitle(`Bir hata oldu!`).setDescription(`${ayarlar.vanilya} **Sanırsam bu özellik zaten kapalı!**`)).then(a => a.delete({timeout: 35000}));
  db.delete(`otoRL_${message.guild.id}`);
  return message.channel.send(new Discord.MessageEmbed().setColor(`#00000`).setTitle(`İşte bu kadar!`).setDescription(`${ayarlar.onayla} **Otorol sistemi başarıyla kapatıldı!**`)).then(a => a.delete({timeout: 15000}));

} else {

if(!rol) return message.channel.send(vanitas.setColor("#000000").setTitle(`Kullanım:`).setDescription(`${ayarlar.vanilya} **Bir rol belirtmelisin!**`)).then(a => a.delete({timeout: 15000}));

db.set(`otoRL_${message.guild.id}`, rol.id)  
return message.channel.send(vanitas.setColor("#000000").setTitle(`İşte bu kadar!`).setDescription(`${ayarlar.onayla} **Otorol sistemi aktif edildi. Sunucuya giren üyelere ${rol} rolü verilecek!**`)).then(a => a.delete({timeout: 15000}));
}
};

exports.config = {
  name: "otorol",
    aliases: []
}