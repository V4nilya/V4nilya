const Discord = require('discord.js');
const db = require('quick.db');
const ayarlar = require("../ayarlar/bot.json");

exports.run = async (client, message, args) => {
  let prefix = await db.fetch(`prefix.${message.guild.id}`) || ayarlar.prefix 
  const nn = new Discord.MessageEmbed()

const kadınroleID = await db.fetch(`kadin.${message.guild.id}`);
if (!kadınroleID) return message.channel.send(nn.setTitle('Bir hata oldu!').setColor("#000000").setDescription(`${ayarlar.vanilya} **\`Kadın\` rolünü ayarlaman gerek!**

**Örnek kullanım:**
\`\`\`${prefix}kadın-rol @kadın-rolü\`\`\``)).then(a => a.delete({timeout: 10000}));

const yetkiliroleID = await db.fetch(`yetkili.${message.guild.id}`);
if (!yetkiliroleID) return message.channel.send(nn.setTitle('Bir hata oldu!').setColor("#000000").setDescription(`${ayarlar.vanilya} **\`Yetkili\` rolünü ayarlaman gerek!**

**Örnek kullanım:**
\`\`\`${prefix}kayıt-yetkili-rol @yetkili-rolü\`\`\``)).then(a => a.delete({timeout: 10000}));

const kayıtsızroleID = await db.fetch(`kayitsiz.${message.guild.id}`);
if (!kayıtsızroleID) return message.channel.send(nn.setTitle('Bir hata oldu!').setColor("#000000").setDescription(`${ayarlar.vanilya} **\`Kayıtsız\` rolünü ayarlaman gerek!**

**Örnek kullanım:**
\`\`\`${prefix}kayıtsız-rol @kayıtsız-rolü\`\`\``)).then(a => a.delete({timeout: 10000}));

const kanalID = await db.fetch(`kayit.kanal.${message.guild.id}`);
if (!kanalID) return message.channel.send(nn.setTitle('Bir hata oldu!').setColor("#000000").setDescription(`${ayarlar.vanilya} **\`Kayıt\` kanalını ayarlaman gerek!**
  
**Örnek kullanım:**
\`\`\`${prefix}kayıt-kanal #kayıtkanalı\`\`\``)).then(a => a.delete({timeout: 10000}));

let member = message.mentions.members.first();
let kadın = message.guild.roles.cache.get(kadınroleID);
let yetkili = message.guild.roles.cache.get(yetkiliroleID);
let kayıtsız = message.guild.roles.cache.get(kayıtsızroleID);
if(!kadın||!kayıtsız||!yetkili) return;

if(message.channel.id !== kanalID) return message.channel.send(nn.setTitle('Bir hata oldu!').setColor("#000000").setDescription(`${ayarlar.vanilya} **Kayıt komutlarını sadece <#${kanalID}> kanalında kullanabilirsin.**`)).then(a => a.delete({timeout: 15000}));

if(!message.member.roles.cache.has(yetkiliroleID)) return message.channel.send(nn.setColor("#000000").setDescription(`${ayarlar.vanilya} **Kayıt yapabilmek için ${yetkili} rolüne ihtiyacın var!**`)).then(a => a.delete({timeout: 15000}));

if(!args[0] || !message.mentions.members.first()) return message.channel.send(nn.setTitle('Bir hata oldu!').setColor('#000001').setDescription(`${ayarlar.vanilya} **Bir üye etiketlemen gerekli!**

**Örnek:**
\`\`\`${prefix}kadın @etiket
${prefix}kadın @etiket İsim\`\`\``)).then(a => a.delete({timeout: 10000}));

let isim;
if(args[1]) {
isim = args.slice(1).join(' ');
} else {
isim = member.user.username;
}

if(!member.roles.cache.has(kayıtsızroleID)) return message.channel.send(nn.setColor('#000000').setDescription(`${ayarlar.vanilya} **Kayıt edeceğim üyede ${kayıtsız} rolü bulunmalı!**`)).then(a => a.delete({timeout: 15000}));
const n = await db.fetch(`kayıt.tag.${message.guild.id}`);

member.roles.add(kadın.id);
member.roles.remove(kayıtsız.id);
db.add(`say.kadin.${message.author.id}.${message.guild.id}`, 1);
if(isim && nn) member.setNickname(n +isim); 
if(isim && !n) member.setNickname(isim);
if(!isim && n) member.setNickname(n +member.user.username);

return message.channel.send(nn.setColor('#000000').setThumbnail().setTitle(`İşte bu kadar!`).setTimestamp().setFooter(`${message.author.username} tarafından kullanıldı`, client.user.avatarURL()).setDescription(`${ayarlar.onayla} ${member} **kullanıcısına ${kadın} rolü verildi!**

${ayarlar.vanilya} **Kayıt eden yetkili ${message.author}**`)
.setImage('https://i.hizliresim.com/hdn7b02.gif'));

};
exports.config = {
  name: "kadın",
    aliases: []
  }