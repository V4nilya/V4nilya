const Discord = require('discord.js');
const db = require('quick.db');
const ayarlar = require("../ayarlar/bot.json");

exports.run = async (client, message, args) => {
  let prefix = await db.fetch(`prefix.${message.guild.id}`) || ayarlar.prefix 

  const vanitas = new Discord.MessageEmbed()  
  .setColor(`#000000`)
  .setAuthor(`${ayarlar.botisim}${ayarlar.isim_eki} rolünü yukarıda tutmayı unutmayın!`, client.user.avatarURL())
  .setDescription(`
  \`\`\`             [ Kullanım Komutları ]            \`\`\`
  ${ayarlar.vanilya} \`${prefix}jail @üye 1dk sebep\`
  **Üyeyi jaile atmak için kullanılır.**
  
  ${ayarlar.vanilya} \`${prefix}unjail @üye\`
  **Üyeyi jailden çıkarmak için kullanılır.**
  
  ${ayarlar.vanilya}** \`Süre Değişkenleri:\` \`1sn - 1dk - 1sa - 1gün\`**
    
  \`\`\`              [ Kurulum Komutları ]            \`\`\`
  ${ayarlar.vanilya} \`${prefix}jail-yetkili-rol @rol\`
  **Jaile atma yetkisi tanır, bu rol olmadan jail işlemi gerçekleşmez.**
  
  ${ayarlar.vanilya} \`${prefix}jail-karantina-rol @rol\`
  **Üye jaile atılırken verilecek rolü belirler.**
  
  ${ayarlar.vanilya} \`${prefix}jail-tahliye-rol @rol\`
  **Üye jailden çıkarılırken verilecek rolü belirler.**

  ${ayarlar.vanilya} \`${prefix}jail-log #logkanalı\`
  **Jail işlemlerinin kaydedileceği kanalını ayarlar.**

  ${ayarlar.vanilya} **\`NOT:\` Belirlediğiniz karantina rolünün**
  **izinlerini odalar için siz ayarlamalısınız.**
  
  \`\`\`             [ Sıfırlama Komutları ]            \`\`\`
  ${ayarlar.vanilya} \`${prefix}jail-yetkili-rol sıfırla\`
  **Jail yetkilisi rolünü sıfırlar.**
  
  ${ayarlar.vanilya} \`${prefix}jail-karantina-rol sıfırla\`
  **Jail karantina rolünü sıfırlar.**

  ${ayarlar.vanilya} \`${prefix}jail-tahliye-rol sıfırla\`
  **Jail tahliye rolünü sıfırlar.**
  
  ${ayarlar.vanilya} \`${prefix}jail-log kapat\`
  **Ayarlı olan jail-log kanalını kapatır**`)
  .setTimestamp()
  .setFooter(`${message.author.username} tarafından kullanıldı`, client.user.avatarURL())
  return message.channel.send(vanitas).then(a => a.delete({timeout: 150000}));
  
};
exports.config = {
  name: 'jail-sistem',
  aliases: []
};
