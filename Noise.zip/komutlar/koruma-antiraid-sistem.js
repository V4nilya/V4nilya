const Discord = require(`discord.js`);
const db = require(`quick.db`);
const ayarlar = require("../ayarlar/bot.json");

exports.run = async (client, message, args) => { 
let prefix = db.fetch(`prefix.${message.guild.id}`) || ayarlar.prefix 
const vanitas = new Discord.MessageEmbed()  
.setColor(`#000000`)
.setAuthor(`${ayarlar.botisim}${ayarlar.isim_eki} rolünü yukarıda tutmayı unutmayın!`, client.user.avatarURL())
.setDescription(`
\`\`\`                [ Kurulum Komutları ]              \`\`\`
${ayarlar.vanilya} \`${prefix}kanal-koruma #kanalkoruma-log\`
**Sunucu sahibi dışında ki hiç kimse kanal silemez ve açamaz.**

${ayarlar.vanilya} \`${prefix}rol-koruma #rolkoruma-log\`
**Sunucu sahibi dışında ki hiç kimse rol silemez ve açamaz.**

${ayarlar.vanilya} \`${prefix}ban-koruma #bankoruma-log\`
**Sunucu sahibi dışındaki herkes belirlenen limite kadar yasaklama yapabilir.**
**ban limiti geçilirse yetkilinin yetkisi otomatik alınır.**
**${ayarlar.sahip} Örnek: \`${prefix}ban-koruma-limit 3\`**

\`\`\`                   [ Hızlı Kullanım ]             \`\`\`
${ayarlar.vanilya} \`${prefix}tam-koruma #koruma-log\`
**1 komut ile tüm korumaları 1 log-kanalına bağlı şekilde aktif edebilirsin. **
**otomatik olarak ban-limitini \`3\`'e ayarlar.**

\`\`\`                 [ Kapatma Komutları ]             \`\`\`
${ayarlar.vanilya} \`${prefix}kanal-koruma kapat\`
**Kanal korumasını kapatır.**

${ayarlar.vanilya} \`${prefix}rol-koruma kapat\`
**Rol korumasını kapatır.**

${ayarlar.vanilya} \`${prefix}ban-koruma kapat\`
**Ban korumasını kapatır ve limiti sıfırlar.**

${ayarlar.vanilya} \`${prefix}tam-koruma kapat\`
**Tüm korumaları tek seferde kapatır!**
`)
.setTimestamp()
.setFooter(`${message.author.username} tarafından kullanıldı`, client.user.avatarURL())
return message.channel.send(vanitas).then(a => a.delete({timeout: 75000}));
};

exports.config = {
  name: "anti-raid",
    aliases: []
  }