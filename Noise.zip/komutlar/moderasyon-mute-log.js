const Discord = require(`discord.js`);
const db = require(`quick.db`);
const ayarlar = require("../ayarlar/bot.json");
  
  exports.run = async (client, message, args) => {
    let prefix = db.fetch(`prefix.${message.guild.id}`) || ayarlar.prefix 
    if(!message.member.permissions.has(`ADMINISTRATOR`)) return message.channel.send(new Discord.MessageEmbed().setColor("#000000").setTitle(`Bir hata oldu!`).setDescription(`${ayarlar.vanilya} **Bu komutu kullanabilmek için \`Yönetici\` yetkisine ihtiyacın var.**`)).then(m => m.delete({timeout: 10000}));  
  if(args[0] === `kapat`) {
  db.delete(`mute.log.${message.guild.id}`);
  return message.channel.send(new Discord.MessageEmbed().setColor(`#00000`).setTitle(`İşte bu kadar!`).setDescription(`**${ayarlar.onayla} \`Mute-Log\` başarıyla kapatıldı!**`)).then(a => a.delete({timeout: 35000}));
  
  } else {
  if(!message.mentions.channels.first()) return message.channel.send(new Discord.MessageEmbed().setColor(`#00000`).setTitle(`Bir hata oldu!`).setDescription(`${ayarlar.vanilya} **Bir kanal etiketlemelisin!**

  **Örnek kullanım:**
  \`\`\`${prefix}mute-log #mutelog-kanalı\`\`\``)).then(a => a.delete({timeout: 10000}));
  
  let mentionChannel = message.mentions.channels.first();
  db.set(`mute.log.${message.guild.id}`, mentionChannel.id);
  return message.channel.send(new Discord.MessageEmbed().setColor(`#00000`).setTitle(`İşte bu kadar!`).setDescription(`${ayarlar.onayla} **\`Mute-Log\` sistemi başarıyla açıldı! ${mentionChannel} kanalı log olarak ayarlandı.**`)).then(a => a.delete({timeout: 35000}));
  }
  };
  
  exports.config = {
    name: "mute-log",
      aliases: []
  }
  