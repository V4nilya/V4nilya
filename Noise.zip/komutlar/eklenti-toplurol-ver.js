const Discord = require(`discord.js`);
const db = require(`quick.db`);
const ayarlar = require("../ayarlar/bot.json");

exports.run = async (client, message, args) => {
let prefix = db.fetch(`prefix.${message.guild.id}`) || ayarlar.prefix 
const vanitas = new Discord.MessageEmbed() 
if(message.author.id !== message.guild.owner.user.id) return message.channel.send(new Discord.MessageEmbed().setColor("#000000").setTitle(`Bir hata oldu!`).setDescription(`${ayarlar.vanilya} **Bu komutu kullanabilmek için \`Sunucu Sahibi\` olmalısın.**`)).then(m => m.delete({timeout: 10000}));

if(!args[0]) return message.channel.send(vanitas.setColor(`#000000`).setTitle(`Bir hata oldu!`).setDescription(`
${ayarlar.vanilya} **Üyelere verilecek rolün \`ID\`'sini belirtmedin!**

**Örnek:**
\`\`\`${prefix}toplurol-ver ${message.guild.roles.cache.random().id}\`\`\``));

if(!message.guild.roles.cache.get(args[0])) return message.channel.send(vanitas.setColor("#000000").setTitle(`Bir hata oldu!`).setDescription(`
${ayarlar.vanilya} **lütfen geçerli bir rol \`ID\` belirt!**

**Örnek:**
\`\`\`${prefix}toplurol-ver ${message.guild.roles.cache.random().id}\`\`\``));

message.channel.send(vanitas.setColor("#000000").setTitle(`İşte bu kadar!`).setDescription(`${ayarlar.onayla} **Sunucunuzda ki üyelere ${message.guild.roles.cache.get(args[0])} rolü veriliyor.**`)).then(a => a.delete({timeout: 15000}));
message.guild.members.cache.forEach(a => {
setTimeout(() => {
if(!a.roles.cache.has(message.guild.roles.cache.get(args[0]).id)) {
a.roles.add(message.guild.roles.cache.get(args[0]).id);
}
}, 2000)
})
};

exports.config = {
  name: "toplurol-ver",
    aliases: []
  }