const Discord = require('discord.js');
const db = require('quick.db');
const ayarlar = require("../ayarlar/bot.json");

exports.run = async (client, message, args) => {
  let prefix = await db.fetch(`prefix.${message.guild.id}`) || ayarlar.prefix 

const yetkiliroleID = await db.fetch(`yetkili.${message.guild.id}`);
if(!message.member.roles.cache.has(yetkiliroleID)) return message.channel.send(new Discord.MessageEmbed().setTitle('Bir hata oldu!').setColor("#000000").setDescription(`**${ayarlar.vanilya} İstatistiği görmek için \`kayıt yetkilisi\` rolüne ihtiyacın var!**`)).then(m => m.delete({timeout: 15000}));

if(!message.mentions.members.first()) {
const datas = await db.fetch(`say.kadin.${message.author.id}.${message.guild.id}`);
const dataa = await db.fetch(`say.erkek.${message.author.id}.${message.guild.id}`);

const embed = new Discord.MessageEmbed().setColor('#000000').setTitle(`Kayıt İstatistiği`).setDescription(`
${ayarlar.sahip} **Yetkili** <@!${message.author.id}>

${ayarlar.vanilya} **Toplam Kayıt Sayısı:** \`${Number(dataa ? dataa : '0')+Number(datas ? datas : '0')}\`
${ayarlar.vanilya} **Erkek Kayıt Sayısı:** \`${dataa ? dataa : '0'}\`
${ayarlar.vanilya} **Kadın Kayıt Sayısı:** \`${datas ? datas : '0'}\``);
return message.channel.send(embed).then(m => m.delete({timeout: 12000}));
} else {
const datas = await db.fetch(`say.kadin.${message.mentions.members.first().id}.${message.guild.id}`);
const dataa = await db.fetch(`say.erkek.${message.mentions.members.first().id}.${message.guild.id}`);

const embed = new Discord.MessageEmbed().setColor('#000000').setTitle(`Kayıt İstatistiği`).setDescription(`
${ayarlar.sahip} **Yetkili** <@!${message.mentions.members.first().id}>

**${ayarlar.vanilya} Toplam Kayıt Sayısı:** \`${Number(dataa ? dataa : '0')+Number(datas ? datas : '0')}\`
**${ayarlar.vanilya} Erkek Kayıt Sayısı:** \`${dataa ? dataa : '0'}\`
**${ayarlar.vanilya} Kadın Kayıt Sayısı:** \`${datas ? datas : '0'}\``);
return message.channel.send(embed).then(m => m.delete({timeout: 12000}));
}
};

exports.config = {
  name: "kayıt-stats",
    aliases: []
  }