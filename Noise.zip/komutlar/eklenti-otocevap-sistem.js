const Discord = require('discord.js');
const db = require("quick.db");
const ayarlar = require("../ayarlar/bot.json");

exports.run = async (client, message, args) => { 
let prefix = await db.fetch(`prefix.${message.guild.id}`) || ayarlar.prefix 
const vanitas = new Discord.MessageEmbed()  
.setColor(`#000000`)
.setAuthor(`${ayarlar.botisim}${ayarlar.isim_eki} rolünü yukarıda tutmayı unutmayın!`, client.user.avatarURL())
.setDescription(`
\`\`\`             [ Kullanım Komutları ]            \`\`\`
${ayarlar.vanilya} \`${prefix}otocevap-1\`
**Sunucunuza özel 1. komut-cevap sistemi kurar.**

${ayarlar.vanilya} \`${prefix}otocevap-2\`
**Sunucunuza özel 2. komut-cevap sistemi kurar.**

${ayarlar.vanilya} \`${prefix}otocevap-3\`
**Sunucunuza özel 3. komut-cevap sistemi kurar.**

**NOT: En fazla 3 adet \`oto-cevap\` sistemi kurabilirsiniz.**

${ayarlar.vanilya} \`${prefix}otocevap-liste\`
**Sunucunuzda kurulan komut-cevap sistemlerini gösterir.**

${ayarlar.vanilya} \`${prefix}otocevap-sil\`
**Kaldırmak istediğiniz komut-cevap sistemini kaldırır.**`)
.setTimestamp()
.setFooter(`${message.author.username} tarafından kullanıldı`, client.user.avatarURL())
return message.channel.send(vanitas).then(a => a.delete({timeout: 150000}));
  
};
exports.config = {
name: "otocevap-sistem",
  aliases: []
}
