const Discord = require(`discord.js`);
const db = require(`quick.db`);
const ayarlar = require("../ayarlar/bot.json");

exports.run = async (client, message, args) => {
  let prefix = await db.fetch(`prefix.${message.guild.id}`) || ayarlar.prefix 
  if(!message.member.permissions.has(`ADMINISTRATOR`)) return message.channel.send(new Discord.MessageEmbed().setColor("#000000").setTitle(`Bir hata oldu!`).setDescription(`${ayarlar.vanilya} **Bu komutu kullanabilmek için \`Yönetici\` yetkisine ihtiyacın var.**`)).then(m => m.delete({timeout: 10000}));
  
  if(args[0] === `sil`) {
    db.delete(`kayıt.tag.${message.guild.id}`);
    return message.channel.send(new Discord.MessageEmbed().setColor(`#00000`).setTitle(`İşte bu kadar!`).setDescription(`${ayarlar.onayla} **Kayıt-Tagı başarıyla sıfırlandı!**`)).then(a => a.delete({timeout: 35000}));
    
    } else {
  if(!args[0]) return message.channel.send(new Discord.MessageEmbed().setColor("#000000").setTitle(`Kullanımlar:`).setTimestamp().setFooter(`${message.author.username} tarafından kullanıldı`, client.user.avatarURL())
  .setDescription(`\`${prefix}kayıt-tag\` \`⭐\``)).then(m => m.delete({timeout: 100000}));
  db.set(`kayıt.tag.${message.guild.id}`, args.slice(0).join(` `));
  return message.channel.send(new Discord.MessageEmbed().setColor("#000000").setTitle(`İşte bu kadar!`).setDescription(`${ayarlar.onayla} **Üyeler kayıt edilirken isimlerinin başına otomatik olarak tagı koyulacak.**`)).then(m => m.delete({timeout: 10000}));
  }
};

exports.config = {
  name: "kayıt-tag",
    aliases: []
  }