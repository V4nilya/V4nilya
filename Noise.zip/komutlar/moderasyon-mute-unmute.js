const Discord = require('discord.js');
const db = require('quick.db');
const ms = require('ms');
const ayarlar = require("../ayarlar/bot.json");

exports.run = async (client, message, args) => {
  let prefix = await db.fetch(`prefix.${message.guild.id}`) || ayarlar.prefix  
  const logChannel = await db.fetch(`mute.log.${message.guild.id}`);
  if(!logChannel) return message.channel.send(new Discord.MessageEmbed().setTitle('Bir hata oldu!').setColor("#000000").setDescription(`${ayarlar.vanilya} **\`Mute-Log\` kanalının ayarlanması gerek!**
  
  **Örnek kullanım:**
  \`\`\`${prefix}mute-log #mutelog-kanalı\`\`\``)).then(a => a.delete({timeout: 10000}));
  
  const muteYetkili = await db.fetch(`muteyetki.role.${message.guild.id}`);
  if(!muteYetkili) return message.channel.send(new Discord.MessageEmbed().setTitle('Bir hata oldu!').setColor("#000000").setDescription(`${ayarlar.vanilya} **\`Mute-Yetkilisi\` rolünün ayarlanması gerek!**
  
  **Örnek kullanım:**
  \`\`\`${prefix}mute-yetkili @rol\`\`\``)).then(a => a.delete({timeout: 10000}));

  if(!message.member.permissions.has(muteYetkili)) return message.channel.send(new Discord.MessageEmbed().setColor("#000000").setDescription(`${message.guild.roles.cache.get(muteYetkili)} | Rolüne sahip olman gerekiyor.`)).then(a => a.delete({timeout: 15000}));

  let mutekisi = message.guild.member(message.mentions.users.first() || message.guild.members.cache.get(args[0]));
  if(!mutekisi) return message.channel.send(new Discord.MessageEmbed().setColor("#000000").setTitle('Bir hata oldu!').setDescription(`**${ayarlar.vanilya} Bir üye etiketlemelisin veya id girmelisin**

  **Örnek kullanım:**
  \`\`\`${prefix}unmute @üye
  
${prefix}unmute 916287683275603488\`\`\``).setTimestamp().setFooter(`${message.author.username} tarafından kullanıldı`, client.user.avatarURL())).then(a => a.delete({timeout: 15000}));

if(message.author.id === mutekisi.id) return message.channel.send(new Discord.MessageEmbed().setColor("#000000").setTitle(`Çok şey istiyorsun`).setDescription(`**${ayarlar.sahip} Bunu yapamam dostum.**`)).then(a => a.delete({timeout: 15000}));
if(mutekisi.roles.highest.position >= message.member.roles.highest.position) return message.channel.send(new Discord.MessageEmbed().setColor("#000000").setDescription(`**${ayarlar.vanilya} Senden üst veya sana eşit birisini muteleyemem.**`)).then(a => a.delete({timeout: 15000}));
if(mutekisi.hasPermission("ADMINISTRATOR")) return message.channel.send(new Discord.MessageEmbed().setColor("#000000").setDescription(`**${ayarlar.vanilya} Yönetici bir kullanıcıya karışamam!**`)).then(a => a.delete({timeout: 15000}));

let embed = new Discord.MessageEmbed()
.setAuthor(`Vanitas`, client.user.avatarURL())
.setColor("#000000")
.addField("Eylem", "\`Chat Susturması Kaldırma\`")
.addField("Susturmayı Kaldıran Yetkili", `<@${message.author.id}>`)
.addField("Susturulması Kaldırılan Üye", `<@${mutekisi.id}>`)
.setFooter(`Vanitas | Susturma Sistemi`, client.user.avatarURL())
.setTimestamp();
client.channels.cache.get(logChannel).send(embed);

message.channel.send(new Discord.MessageEmbed()
.setAuthor(`Vanitas`, client.user.avatarURL())
.setColor("#000000")
.setTitle('Mute Sistem')
.setDescription(`**${ayarlar.vanilya} <@${mutekisi.id}> kullanıcısının chat mutesi kaldırıldı!**`)
.setFooter(`Vanitas | Susturma Sistemi`, client.user.avatarURL())
.setTimestamp());

message.guild.channels.cache.filter(a => a.type === 'text').forEach(s => {
s.overwritePermissions([{ id: mutekisi.id, null: ['SEND_MESSAGES'] }]);
});

};

exports.config = {
  name: "unmute",
    aliases: []
}