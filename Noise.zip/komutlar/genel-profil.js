const Discord = require(`discord.js`)
const moment = require(`moment`)
const ayarlar = require("../ayarlar/bot.json");

exports.run = async (client, msg, args) => {

        let user = msg.mentions.users.first() || msg.author;
  
        let userinfo = {};
        userinfo.avatar= user.avatarURL();
        userinfo.id = user.id;
        userinfo.od1 = msg.guild.members.cache.get(user.id).user.presence.game || "Oynadığı bir oyun yok"
        userinfo.status = user.presence.status.toString()
        .replace("dnd", `<:sessiz:901932139073921064> | **Rahatsız Etmeyin**`)
        .replace("online", `<:online:901932131247333407> | **Çevrimiçi**`)
        .replace("idle", `<:uzakta:901932146120331354> | **Boşta**`)
        .replace("offline", `<:offline:901932153770745918> | **Çevrimdışı**`)

        userinfo.bot = user.bot.toString()
        .replace("false", `Hayır`)
        .replace("true", `Evet`)

        userinfo.sonmesaj = user.lastMessage || "Son yazılan mesaj bulunamadı." || "Son yazılan mesaj gösterilemedi."
        userinfo.dctarih = moment.utc(msg.guild.members.cache.get(user.id).user.createdAt).format(`**YYYY** [Yılında] MMMM [Ayında] dddd [Gününde] (**DD/MM/YYYY**)`)

        .replace("Monday", `**Pazartesi**`)
        .replace("Tuesday", `**Salı**`)
        .replace("Wednesday", `**Çarşamba**`)
        .replace("Thursday", `**Perşembe**`)
        .replace("Friday", `**Cuma**`)
        .replace("Saturday", `**Cumartesi**`)
        .replace("Sunday", `**Pazar**`)

        .replace("January", `**Ocak**`)
        .replace("February", `**Şubat**`)
        .replace("March", `**Mart**`)
        .replace("April", `**Nisan**`)
        .replace("May", `**Mayıs**`)
        .replace("June", `**Haziran**`)
        .replace("July", `**Temmuz**`)
        .replace("August", `**Ağustos**`)
        .replace("September", `**Eylül**`)
        .replace("October", `**Ekim**`)
        .replace("November", `**Kasım**`)
        .replace("December", `**Aralık**`)
        userinfo.dctarihkatilma = moment.utc(msg.guild.members.cache.get(user.id).joinedAt).format(`**YYYY** [Yılında] MMMM [Ayında] dddd [Gününde] (**DD/MM/YYYY**)`)
        .replace("Monday", `**Pazartesi**`)
        .replace("Tuesday", `**Salı**`)
        .replace("Wednesday", `**Çarşamba**`)
        .replace("Thursday", `**Perşembe**`)
        .replace("Friday", `**Cuma**`)
        .replace("Saturday", `**Cumartesi**`)
        .replace("Sunday", `**Pazar**`)

        .replace("January", `**Ocak**`)
        .replace("February", `**Şubat**`)
        .replace("March", `**Mart**`)
        .replace("April", `**Nisan**`)
        .replace("May", `**Mayıs**`)
        .replace("June", `**Haziran**`)
        .replace("July", `**Temmuz**`)
        .replace("August", `**Ağustos**`)
        .replace("September", `**Eylül**`)
        .replace("October", `**Ekim**`)
        .replace("November", `**Kasım**`)
        .replace("December", `**Aralık**`)
 
        const embed = new Discord.MessageEmbed()
        .setAuthor(user.tag, userinfo.avatar)
        .setThumbnail(userinfo.avatar)
        .setDescription(`\`\`\`          [ Kullanıcı Bilgileri ]        \`\`\``) 
        .addField(`${ayarlar.vanilya} Durum`, userinfo.status, false)
        .setColor(`#000000`)
        .addField(`${ayarlar.onayla} Sunucuya Giriş Tarihi`, userinfo.dctarihkatilma, false)
        .addField(`${ayarlar.onayla} Hesabın Oluşturulma Tarihi`, userinfo.dctarih, false)
        .addField(`Kimlik`, userinfo.id, true)
        .addField(`Bot mu?`, userinfo.bot, true)
        .setTimestamp()
        .setFooter(`${msg.author.username} tarafından kullanıldı`, client.user.avatarURL())
        return msg.channel.send(embed).then(a => a.delete({timeout: 50000}));
    }

exports.config = {
  name: `profil`,
  aliases: []
};



