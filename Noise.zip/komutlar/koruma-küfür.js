const Discord = require(`discord.js`);
const db = require(`quick.db`);
const ayarlar = require("../ayarlar/bot.json");

exports.run = async (client, message, args) => {
  let prefix = await db.fetch(`prefix.${message.guild.id}`) || ayarlar.prefix 
  const vanitas = new Discord.MessageEmbed()
  if(!message.member.permissions.has(`ADMINISTRATOR`)) return message.channel.send(vanitas.setColor("#000000").setTitle(`Bir hata oldu!`).setDescription(`${ayarlar.vanilya} **Bu komutu kullanabilmek için \`Yönetici\` yetkisine ihtiyacın var.**`)).then(m => m.delete({timeout: 10000}));

if(!args[0]) return message.channel.send(vanitas.setColor(`#00000`).setTitle(`Kullanım:`).setDescription(`${ayarlar.vanilya} **Küfür kısıtlamak istersen** \`${prefix}küfür kısıtla\` **yazmalısın.**`)).then(a => a.delete({timeout: 15000}));
if(args[0] === `kısıtla`) {
db.set(`küfür.${message.guild.id}`, true);
return message.channel.send(vanitas.setColor("#000000").setTitle(`İşte bu kadar!`).setDescription(`${ayarlar.onayla} **Küfür kısıtlaması başarıyla açıldı!**`)).then(a => a.delete({timeout: 10000}));
} else if(args[0] === `kapat`) {
db.delete(`küfür.${message.guild.id}`);
return message.channel.send(vanitas.setColor("#000000").setTitle(`İşte bu kadar!`).setDescription(`${ayarlar.onayla} **Küfür kısıtlaması başarıyla kapatıldı!**`)).then(a => a.delete({timeout: 10000}));
}
};

exports.config = {
  name: "küfür",
    aliases: []
  }