const Discord = require(`discord.js`);
const ayarlar = require("../ayarlar/bot.json");

exports.run = async(client, msg) => {
if(!msg.member.permissions.has(`ADMINISTRATOR`)) return msg.channel.send(new Discord.MessageEmbed().setColor("#000000").setTitle(`Bir hata oldu!`).setDescription(`${ayarlar.vanilya} **Bu komutu kullanabilmek için \`Yönetici\` yetkisine ihtiyacın var.**`)).then(m => m.delete({timeout: 10000}));
function checkDays(date) {
            let now = new Date();
            let diff = now.getTime() - date.getTime();
            let days = Math.floor(diff / 86400000);
            return days + (days == 1 ? " gün" : " gün") + " önce";
        };
        let guild = msg.channel.guild
        let serverSize = msg.guild.memberCount;
        let botCount = msg.guild.members.cache.filter(m => m.user.bot).size;
        let humanCount = serverSize - botCount;

const sunucu = new Discord.MessageEmbed()
.setAuthor(`${ayarlar.botisim}`, client.user.avatarURL())
.setColor(`#000000`)
.addField(`Sunucu Bilgileri`, `**${ayarlar.vanilya} Sunucu Adı:** \`${guild.name}\` \n**${ayarlar.vanilya} Sunucu ID:** \`${msg.guild.id}\` \n**${ayarlar.vanilya} Kuruluş Tarihi:** \`${checkDays(msg.guild.createdAt)}\` \n**${ayarlar.vanilya} Sunucu Sahibi:** ${guild.owner}`)
.addField(`Üye Bilgileri`, `**${ayarlar.vanilya} Toplam Üye:** \`${humanCount}\` \n**${ayarlar.vanilya} Toplam Bot:** \`${botCount}\``)
.addField(`Kanallar ve Roller`, `**${ayarlar.vanilya} Rol:** \`${guild.roles.cache.size}\` \n** ${ayarlar.vanilya} Yazı:** \`${msg.guild.channels.cache.filter(c => c.type === `text`).size}\` \n**${ayarlar.vanilya} Sesli:** \`${msg.guild.channels.cache.filter(c => c.type === `voice`).size}\` \n**${ayarlar.vanilya} Kategori:** \`${msg.guild.channels.cache.filter(c => c.type === `category`).size}\``)
.setTimestamp()
.setFooter(`${msg.author.username} tarafından kullanıldı`, client.user.avatarURL())
  return msg.channel.send(sunucu).then(a => a.delete({timeout: 50000}));

};

exports.config = {
  name: `sunucu`,
  aliases: []
};