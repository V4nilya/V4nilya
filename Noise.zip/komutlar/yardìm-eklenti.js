const db = require("quick.db");
const Discord = require('discord.js');
const ayarlar = require("../ayarlar/bot.json");

exports.run = async (client, message, args) => { 
let prefix = await db.fetch(`prefix.${message.guild.id}`) || ayarlar.prefix 

let vanitas = new Discord.MessageEmbed() 
.setColor('#000000') 
.setAuthor(`${ayarlar.botisim}${ayarlar.isim_eki} rolünü yukarıda tutmayı unutmayın!`, client.user.avatarURL())
.setDescription(`\`\`\`                   [ Eklenti Menüsü ]              \`\`\`
${ayarlar.vanilya} \`${prefix}otomesaj\` *[Yönetici]*
**Selam, Günaydın vb şeyler için otomesaj gönderir.**

${ayarlar.vanilya} \`${prefix}otocevap-sistem\` *[Yönetici]*
**Sunucunuza sizin ayarlayabileceğiniz 3 adet komut-cevap hakkı sunar.**

${ayarlar.vanilya} \`${prefix}kayıt-sistem\` *[Yönetici]*
**Sunucunuza giren kişilere kayıtsız rolü verilir ve yetkililer üyeleri kayıt eder.**

${ayarlar.vanilya} \`${prefix}otoisim-sistem\` *[Yönetici]*
**Sunucunuza giren kişilerin nicklerine tag & isim koydurtabilirsiniz.**

${ayarlar.vanilya} \`${prefix}sayaç-sistem\` *[Yönetici]*
**Sunucunuza sayaç sistemi kurabilirsiniz.**

${ayarlar.vanilya} \`${prefix}otorol-sistem\` *[Yönetici]*
**Sunucunuza giren üyelere otomatik rol verebilirsiniz.**

${ayarlar.vanilya} \`${prefix}tagrol-sistem\` *[Yönetici]*
**Belirlenen tag alındığında üyeye rol verir tag çıkarıldığında ise rolü alır.**

${ayarlar.vanilya} \`${prefix}toplurol-sistem\` *[Sunucu Sahibi]*
**Sunucuda ki tüm üyelere rol verip alabilirsiniz.**

${ayarlar.vanilya} \`${prefix}arındır-sistem\` *[Sunucu Sahibi]*
**Sunucuda ki tüm rolleri ve kanalları kolayca silebilirsiniz.**

${ayarlar.kalp} **NOT: \`Seviye Sistemi\`, \`Yasaklı-Tag Sistemi\`, \`Uyarı Sistemi\` VB
üşenmezsem kısa sürede gelecektir. Vanilyalı Dondurmağğğğğ**`)
.setTimestamp()
.setFooter(`${message.author.username} tarafından kullanıldı`, client.user.avatarURL())
return message.channel.send(vanitas).then(a => a.delete({timeout: 50000}));
};

exports.config = {
name: "eklenti",
  aliases: []
}
