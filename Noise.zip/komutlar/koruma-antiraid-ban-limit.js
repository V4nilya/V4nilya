const Discord = require("discord.js");
const db = require(`quick.db`);
const ayarlar = require("../ayarlar/bot.json");

exports.run = async (client, message, args) => {
  let prefix = await db.fetch(`prefix.${message.guild.id}`) || ayarlar.prefix 
  if(message.author.id !== message.guild.owner.user.id) return message.channel.send(new Discord.MessageEmbed().setColor("#000000").setTitle(`Bir hata oldu!`).setDescription(`${ayarlar.vanilya} **Bu komutu kullanabilmek için \`Sunucu Sahibi\` olmalısın.**`)).then(m => m.delete({timeout: 10000}));

  let limit = args[0]
if(args[0] === `sıfırla`) {
  db.delete(`banlimit_${message.guild.id}`);
  return message.channel.send(new Discord.MessageEmbed().setColor(`#00000`).setTitle(`İşte bu kadar!`).setDescription(`**${ayarlar.onayla} Ban limiti sıfırlandı!**`)).then(a => a.delete({timeout: 35000}));
  
  } else {
    if(!args[0] || isNaN(args[0])) return message.channel.send(new Discord.MessageEmbed().setColor(`#00000`).setTitle(`Bir hata oldu!`).setDescription(`${ayarlar.vanilya} **Bir sayı belirtmelisin!**`)).then(a => a.delete({timeout: 35000}));
    if(args[0] <= 0) return message.channel.send(new Discord.MessageEmbed().setColor(`#00000`).setTitle(`Bir hata oldu!`).setDescription(`${ayarlar.vanilya} **Belirttiğin sayı \`0'dan\` büyük olmalı!**`)).then(a => a.delete({timeout: 35000}));
    db.set(`banlimit_${message.guild.id}`, limit);
  return message.channel.send(new Discord.MessageEmbed().setColor(`#00000`).setTitle(`İşte bu kadar!`).setDescription(`${ayarlar.onayla} **Ban limiti \`${limit}\` olarak ayarlandı!**`)).then(a => a.delete({timeout: 35000}));
  }
};

exports.config = {
  name: "ban-koruma-limit",
    aliases: []
}

