const Discord = require("discord.js")
const db = require('quick.db')
const ayarlar = require("../ayarlar/bot.json");

exports.run = async(client, message, args) => {

if(!message.member.permissions.has(`ADMINISTRATOR`)) return message.channel.send(new Discord.MessageEmbed().setColor("#000000").setTitle(`Bir hata oldu!`).setDescription(`${ayarlar.vanilya} **Bu komutu kullanabilmek için \`Yönetici\` yetkisine ihtiyacın var.**`)).then(m => m.delete({timeout: 10000}));
  
let komut = await db.fetch(`sunucuKomut_${message.guild.id}`)
if(!komut) await db.set(`sunucuKomut_${message.guild.id}`, '1 Bulunmuyor.')

let komut2 = await db.fetch(`sunucuKomut2_${message.guild.id}`)
if(!komut2) await db.set(`sunucuKomut2_${message.guild.id}`, '2 Bulunmuyor.')

let komut3 = await db.fetch(`sunucuKomut3_${message.guild.id}`)
if(!komut3) await db.set(`sunucuKomut3_${message.guild.id}`, '3 Bulunmuyor.')
                               
let embed = new Discord.MessageEmbed()
.setColor(`#000000`)
.setTitle(`Mevcut özel komutlar`)
.setDescription(`**${ayarlar.vanilya} \`${komut}\` - \`${komut2}\` - \`${komut3}\`**`)
.setTimestamp()
.setFooter(`${message.author.username} tarafından kullanıldı`, client.user.avatarURL())
return message.channel.send(embed).then(a => a.delete({timeout: 150000}));
};

exports.config = {
  name: "otocevap-liste",
    aliases: []
  }
