const db = require("quick.db");
const Discord = require('discord.js');
const ayarlar = require("../ayarlar/bot.json");

exports.run = async (client, message, args) => { 
let prefix = await db.fetch(`prefix.${message.guild.id}`) || ayarlar.prefix 

let vanitas = new Discord.MessageEmbed() 
.setColor('#000000')
.setAuthor(`${ayarlar.botisim}${ayarlar.isim_eki} rolünü yukarıda tutmayı unutmayın!`, client.user.avatarURL())
.setDescription(`\`\`\`                 [ Yardım Menüsü ]                \`\`\``) 
.addField(`Genel Komutlar`,`${ayarlar.vanilya} \`${prefix}genel\``,true)
.addField(`Yetkili Komutları`,`${ayarlar.vanilya} \`${prefix}moderasyon\``,true)
.addField(`Koruma Komutları`,`${ayarlar.vanilya} \`${prefix}koruma\``,true)
.addField(`Eğlence Komutları`,`${ayarlar.vanilya} \`${prefix}eğlence\``,true)
.addField(`Müzik Komutları`,`${ayarlar.vanilya} \`${prefix}müzik [Yakında]\``,true)
.addField(`Eklenti Komutları`,`${ayarlar.vanilya} \`${prefix}eklenti\``,true)
.addField(`Ek Bilgiler`,`${ayarlar.kalp} **Prefix'i sunucunuza özel değiştirmek isterseniz \`${prefix}prefix\`**\n${ayarlar.kalp} **${ayarlar.botisim}'ı sunucunuza eklemek isterseniz [tıklayın.](https://discord.com/oauth2/authorize?client_id=${client.user.id}&scope=bot&permissions=8)**`)
.setTimestamp()
.setImage('https://i.hizliresim.com/e4llh5i.gif')
.setFooter(`${message.author.username} tarafından kullanıldı`, client.user.avatarURL())
return message.channel.send(vanitas).then(a => a.delete({timeout: 50000}));
};

exports.config = {
name: "yardım",
  aliases: []
}