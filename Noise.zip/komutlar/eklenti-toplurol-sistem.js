const Discord = require(`discord.js`);
const db = require(`quick.db`);
const ayarlar = require("../ayarlar/bot.json");

exports.run = async (client, message, args) => {
let prefix = db.fetch(`prefix.${message.guild.id}`) || ayarlar.prefix 
const vanitas = new Discord.MessageEmbed()  
.setColor(`#000000`)
.setAuthor(`${ayarlar.botisim}${ayarlar.isim_eki} rolünü yukarıda tutmayı unutmayın!`, client.user.avatarURL())
.setDescription(`
\`\`\`                 [ Kullanım ]                 \`\`\`
${ayarlar.vanilya} \`${prefix}toplurol-al\`
**Rolün \`ID\`'sini girerek herkesten o rolü alabilirsin.**

${ayarlar.vanilya} \`${prefix}toplurol-ver\`
**Rolün \`ID\`'sini girerek herkese o rolü verebilirsin.**`)
.setTimestamp()
.setFooter(`${message.author.username} tarafından kullanıldı`, client.user.avatarURL())
return message.channel.send(vanitas).then(a => a.delete({timeout: 150000}));
};

exports.config = {
  name: "toplurol-sistem",
    aliases: []
  }