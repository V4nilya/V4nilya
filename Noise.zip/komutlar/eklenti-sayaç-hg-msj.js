const Discord = require(`discord.js`);
const db = require(`quick.db`);
const ayarlar = require("../ayarlar/bot.json");

exports.run = (client, message, args) => { 
  let prefix = db.fetch(`prefix.${message.guild.id}`) || ayarlar.prefix 
  const vanitas = new Discord.MessageEmbed()  
  if(!message.member.permissions.has(`ADMINISTRATOR`)) return message.channel.send(new Discord.MessageEmbed().setColor("#000000").setTitle(`Bir hata oldu!`).setDescription(`${ayarlar.vanilya} **Bu komutu kullanabilmek için \`Yönetici\` yetkisine ihtiyacın var.**`)).then(m => m.delete({timeout: 10000}));
  
  let mesaj = args.slice(0).join(` `);
  if(args[0] === `sıfırla`) {
  db.delete(`sayacHG_${message.guild.id}`);
  return message.channel.send(new Discord.MessageEmbed().setColor(`#00000`).setTitle(`İşte bu kadar!`).setDescription(`**${ayarlar.onayla} Sayaç hoş geldin mesajı ilk haline getirildi!**`)).then(a => a.delete({timeout: 35000}));
  
  } else {

if(mesaj.length < 5) return message.channel.send(vanitas.setColor("#000000").setTitle(`Kullanım:`).setDescription(`
${ayarlar.vanilya} **Örnek:**

**\`+sunucu\`'a hoş geldin \`+üye\`, \`+hedefüye\` kişi olmak için \`+kalanüye\` kişi kaldı artık \`+toplamüye\` kişiyiz!**

**\`Vanitas\`'a hoş geldin \`Vanilya\`, \`10\` kişi olmak için \`6\` kişi kaldı artık \`4\` kişiyiz!**`)).then(a => a.delete({timeout: 150000}));
  
db.set(`sayacHG_${message.guild.id}`, mesaj)
return message.channel.send(vanitas.setColor("#000000").setTitle(`İşte bu kadar!`).setDescription(`${ayarlar.onayla} **Sayaç hoş geldin mesajını \`${mesaj}\` olarak ayarladım. **`)).then(a => a.delete({timeout: 35000}));
  }
};
  exports.config = {
    name: "sayaç-hg-mesaj",
      aliases: []
    }