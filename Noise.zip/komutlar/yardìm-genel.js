const db = require("quick.db");
const Discord = require('discord.js');
const ayarlar = require("../ayarlar/bot.json");

exports.run = async (client, message, args) => { 
let prefix = await db.fetch(`prefix.${message.guild.id}`) || ayarlar.prefix 

let vanitas = new Discord.MessageEmbed() 
.setAuthor(`${ayarlar.botisim}${ayarlar.isim_eki} rolünü yukarıda tutmayı unutmayın!`, client.user.avatarURL())
.setColor('#000000')
.setDescription(`\`\`\`               [ Genel Menü ]               \`\`\`
${ayarlar.vanilya} \`${prefix}afk\` *[Herkes]*
**Kendini AFK olarak ayarlayabilirsin, istersen sebepte belirtebilirsin**

${ayarlar.vanilya} \`${prefix}avatar\` *[Herkes]*
**Profil fotoğrafınızı gösterir.**

${ayarlar.vanilya} \`${prefix}profil\` *[Herkes]*
**Hesap bilgilerinizi gösterir.**

${ayarlar.vanilya} \`${prefix}sunucu\` *[Yönetici]*
**Sunucu yetkilisine sunucu istatisliğini verir.**`)
.setTimestamp()
.setFooter(`${message.author.username} tarafından kullanıldı`, client.user.avatarURL())
return message.channel.send(vanitas).then(a => a.delete({timeout: 50000}));
};

exports.config = {
name: "genel",
  aliases: []
}


