const Discord = require(`discord.js`);
const db = require(`quick.db`);
const ayarlar = require("../ayarlar/bot.json");

exports.run = async (client, message, args) => {
  let prefix = await db.fetch(`prefix.${message.guild.id}`) || ayarlar.prefix 
  if(!message.member.permissions.has(`ADMINISTRATOR`)) return message.channel.send(new Discord.MessageEmbed().setColor("#000000").setTitle(`Bir hata oldu!`).setDescription(`${ayarlar.vanilya} **Bu komutu kullanabilmek için \`Yönetici\` yetkisine ihtiyacın var.**`)).then(m => m.delete({timeout: 10000}));
  
if(args[0] === `kapat`) {
db.delete(`otoisim.log.${message.guild.id}`);
return message.channel.send(new Discord.MessageEmbed().setColor(`#00000`).setTitle(`İşte bu kadar!`).setDescription(`${ayarlar.onayla} \`otoisim-log\` **kanalı başarıyla kapatıldı!**`)).then(a => a.delete({timeout: 35000}));

} else {
  
  if(!message.mentions.channels.first()) return message.channel.send(new Discord.MessageEmbed().setColor(`#00000`).setTitle(`Bir hata oldu!`).setDescription(`${ayarlar.vanilya} **Bir kanal etiketlemelisin!**`)).then(m => m.delete({timeout: 10000}));
  let mentionChannel = message.mentions.channels.first();
  db.set(`otoisim.log.${message.guild.id}`, mentionChannel.id);
  return message.channel.send(new Discord.MessageEmbed().setColor("#000000").setTitle(`İşte bu kadar!`).setDescription(`${ayarlar.onayla} **\`otoisim-log\` Kanalı başarıyla** ${mentionChannel} **kanalı olarak ayarlandı!**`)).then(m => m.delete({timeout: 10000}));
}
};
exports.config = {
  name: "otoisim-log",
    aliases: []
  }