const Discord = require(`discord.js`);
const db = require(`quick.db`);
const ayarlar = require("../ayarlar/bot.json");

exports.run = async (client, message, args) => { 
let prefix = db.fetch(`prefix.${message.guild.id}`) || ayarlar.prefix 
const vanitas = new Discord.MessageEmbed()  
.setColor(`#000000`)
.setAuthor(`${ayarlar.botisim}${ayarlar.isim_eki} rolünü yukarıda tutmayı unutmayın!`, client.user.avatarURL())
.setDescription(`
\`\`\`              [ Kurulum Komutları ]              \`\`\`
${ayarlar.vanilya} \`${prefix}sayaç #kanal sayı\`
**Sayaç sistemini aktif edersin!**

${ayarlar.vanilya} \`${prefix}sayaç-hg-mesaj\`
**Sayaç hoş geldin mesajını istediğin gibi ayarlayabilirsin!**

${ayarlar.vanilya} \`${prefix}sayaç-bb-mesaj\`
**Sayaç görüşürüz mesajını istediğin gibi ayarlayabilirsin!**

\`\`\`             [ Kapatma Komutları ]             \`\`\`
${ayarlar.vanilya} \`${prefix}sayaç kapat\`
**Sayaç sistemini kapatır!**

${ayarlar.vanilya} \`${prefix}sayaç-hg-mesaj sıfırla\`
**Sayaç hoş geldin mesajını ilk haline getirir!**

${ayarlar.vanilya} \`${prefix}sayaç-bb-mesaj sıfırla\`
**Sayaç görüşürüz mesajını ilk haline getirir!**

\`\`\`                [ Değişkenler ]                \`\`\`
\`+üye\` = **üyeyi etikerler**
\`+sunucu\` = **sunucu adını yazar**
\`+toplamüye\` = **toplam üyeyi gösterir**
\`+kalanüye\` = **sayaca ulaşmak için kalan üye sayısını gösterir**
\`+hedefüye\` = **sayaca ayarlanan hedef üye sayısını gösterir**`)
.setTimestamp()
.setFooter(`${message.author.username} tarafından kullanıldı`, client.user.avatarURL())
return message.channel.send(vanitas).then(a => a.delete({timeout: 150000}));
};

exports.config = {
  name: "sayaç-sistem",
    aliases: []
  }