const db = require("quick.db");
const Discord = require('discord.js');
const ayarlar = require("../ayarlar/bot.json");

exports.run = async (client, message, args) => { 
let prefix = await db.fetch(`prefix.${message.guild.id}`) || ayarlar.prefix 

let vanitas = new Discord.MessageEmbed() 
.setAuthor(`${ayarlar.botisim}${ayarlar.isim_eki} rolünü yukarıda tutmayı unutmayın!`, client.user.avatarURL())
.setColor('#000000')
.setDescription(`\`\`\`               [ Eğlence Menüsü ]               \`\`\`
${ayarlar.vanilya} \`${prefix}aşk\`
**Hadi birisiyle aşk derecenizi ölçelim!**`)
.setTimestamp()
.setFooter(`${message.author.username} tarafından kullanıldı`, client.user.avatarURL())
return message.channel.send(vanitas).then(a => a.delete({timeout: 50000}));
};

exports.config = {
name: "eğlence",
  aliases: []
}

