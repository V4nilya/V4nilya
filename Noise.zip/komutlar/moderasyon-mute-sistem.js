const Discord = require('discord.js');
const db = require('quick.db');
const ayarlar = require("../ayarlar/bot.json");

exports.run = async (client, message, args) => {
let prefix = await db.fetch(`prefix.${message.guild.id}`) || ayarlar.prefix 
const vanitas = new Discord.MessageEmbed()  
.setColor(`#000000`)
.setAuthor(`${ayarlar.botisim}${ayarlar.isim_eki} rolünü yukarıda tutmayı unutmayın!`, client.user.avatarURL())
.setDescription(`
\`\`\`             [ Kullanım Komutları ]            \`\`\`
${ayarlar.vanilya} \`${prefix}mute @üye 1dk sebep\`
**Yazılı kanallarda susturmak için kullanılır.**

${ayarlar.vanilya} \`${prefix}muteses @üye 1dk sebep\`
**Sesli odalarda susturmak için kullanılır.**

${ayarlar.vanilya} \`${prefix}unmute @üye\`
**Yazılı kanaldaki susturmayı kaldırır.**

${ayarlar.vanilya} \`${prefix}unmuteses @üye\`
**Sesli odadaki susturmayı kaldırır.**

${ayarlar.vanilya}** \`Süre Değişkenleri:\` \`1sn - 1dk - 1sa - 1gün\`**
  
\`\`\`              [ Kurulum Komutları ]            \`\`\`
${ayarlar.vanilya} \`${prefix}mute-chat-yetkili @rol\`
**Yazılı kanallarda susturma yetkisi tanır, 
bu rol olmadan susturma işlemi gerçekleşmez.**

${ayarlar.vanilya} \`${prefix}mute-ses-yetkili @rol\`
**Sesli odalarda susturma yetkisi tanır,
bu rol olmadan susturma işlemi gerçekleşmez.**

${ayarlar.vanilya} \`${prefix}mute-log #log-kanal\`
**Susturma işlemlerinin kaydedileceği kanalı belirler.**

\`\`\`             [ Sıfırlama Komutları ]            \`\`\`
${ayarlar.vanilya} \`${prefix}mute-chat-yetkili sıfırla\`
**Ayarlı olan mute yetki rolünü sıfırlar**

${ayarlar.vanilya} \`${prefix}mute-ses-yetkili sıfırla\`
**Ayarlı olan ses mute yetki rolünü sıfırlar**

${ayarlar.vanilya} \`${prefix}mute-log kapat\`
**Ayarlı olan mute-log kanalını kapatır**`)
.setTimestamp()
.setFooter(`${message.author.username} tarafından kullanıldı`, client.user.avatarURL())
return message.channel.send(vanitas).then(a => a.delete({timeout: 150000}));
};

exports.config = {
  name: "mute-sistem",
    aliases: []
  }