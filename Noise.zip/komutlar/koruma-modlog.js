const Discord = require('discord.js')
const db = require('quick.db')
const ayarlar = require("../ayarlar/bot.json");

exports.run = async (client, message, args) => {
let prefix = await db.fetch(`prefix.${message.guild.id}`) || ayarlar.prefix 
const vanitas = new Discord.MessageEmbed()
if(!message.member.permissions.has('ADMINISTRATOR')) return message.channel.send(vanitas.setColor("#000000").setTitle('Bir hata oldu!').setDescription(`${ayarlar.vanilya} **Bu komutu kullanabilmek için \`Yönetici\` yetkisine ihtiyacın var.**`)).then(m => m.delete({timeout: 10000}));

let logk = message.mentions.channels.first();
let logkanal = await db.fetch(`log_${message.guild.id}`)
  
  if (args[0] === "sıfırla" || args[0] === "kapat") {
    
    if(!logkanal) return message.channel.send(vanitas.setColor('#00000').setTitle('Bir hata oldu!').setDescription(`${ayarlar.vanilya} **Modlog Kanalı Zaten ayarlı değil**`)).then(a => a.delete({timeout: 15000}));
    db.delete(`log_${message.guild.id}`)
    message.channel.send(vanitas.setColor("#000000").setTitle(`İşte bu kadar!`).setDescription(`${ayarlar.onayla} **ModLog kanalı başarıyla sıfırlandı.**`)).then(a => a.delete({timeout: 10000}));
    return
  }
  
if (!logk) return message.channel.send(vanitas.setColor("#000000").setTitle(`Kullanım:`).setDescription(`${ayarlar.vanilya} **Bir \`Mod-Log\` kanalı belirtmelisin.**

**Örnek kullanım:**
\`\`\`${prefix}modlog #modlog-kanalı\`\`\``)).then(a => a.delete({timeout: 10000}));

db.set(`log_${message.guild.id}`, logk.id)

return message.channel.send(vanitas.setColor("#000000").setTitle(`İşte bu kadar!`).setDescription(`${ayarlar.onayla} **ModLog kanalı başarıyla** ${logk} **olarak ayarlandı.**`)).then(a => a.delete({timeout: 10000}));
};

exports.config = {
    name: "modlog",
    aliases: ["mod-log","modlog","log"]
}