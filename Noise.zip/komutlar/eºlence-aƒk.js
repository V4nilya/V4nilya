const Discord = require('discord.js')
const ayarlar = require("../ayarlar/bot.json");
 
exports.run = async (client, message, args) => {
        let member = message.guild.member(message.mentions.users.array()[0] || message.guild.members.cache.get(args[0]))
        let member2 = message.guild.member(message.mentions.users.array()[1] || message.guild.members.cache.get(args[1]))
        var s = message.author
        if(member2) {
                var s = member2.user
        }
        if(!member) {
                const embed = new Discord.MessageEmbed()
                        .setDescription(`${ayarlar.kalp} **Aşkını ölçeceğim kişiyide etiketlemelisin!**`)
                        .setColor("#000000")
                        .setTimestamp()
                        .setFooter(`${message.author.username} tarafından kullanıldı`, client.user.avatarURL())
                return message.channel.send({embed})
        }
 
        var anasonuc = Math.floor(Math.random() * 101)
        var kalp = ''
        var akalp = ''
        if(Math.floor(Math.round(anasonuc / 10) * 10) >= 10) {
                var c = 0
                for(var i = 0; i < Math.floor(Math.round(anasonuc / 10)); i++) {
                        kalp += '💖'
                        c++
                }
                for(var x = c; x < 10; x++) {
                        akalp += `🖤`
                }
        } else {
                var kalp = '🖤'
                var akalp = '🖤🖤🖤🖤🖤🖤🖤🖤🖤'
        }
        var yorum = `Eeee düğün ne zaman? <3`
        if(anasonuc < 80) {
                var yorum = 'Bence bu iş oldu sayılır.'
        }
        if(anasonuc < 60) {
                var yorum = 'Biraz kaynaşma ve zaman ile olabilir.'
        }
        if(anasonuc < 40) {
                var yorum = 'Sanki ucundan kıpırdama var gibi.'
        }
        if(anasonuc < 20) {
                var yorum = 'Bu iş olmaz sen unut bu aşkı'
        }
        if(member.user.id == s.id) {
                var yorum = 'Kendine olan aşkını ölçmek? ilginç..'
        }
        const embed = new Discord.MessageEmbed()
        .setTitle(`Aşk Ölçer`)
        .setDescription(`<@${member.user.id}> ❤ <@${s.id}>\n\n**Aşkınız %${anasonuc}**\n**${kalp}${akalp}**\n\n**${ayarlar.kalp} \`${yorum}\`**`)
        .setColor("#ff6f9c")
        .setTimestamp()
        .setFooter(`${message.author.username} tarafından kullanıldı`, client.user.avatarURL())
        return message.channel.send(embed);
}
 
exports.config = {
    name: "aşk",
      aliases: []
    }