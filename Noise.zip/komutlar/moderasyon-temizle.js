const Discord = require('discord.js');
const db = require('quick.db');
const ayarlar = require("../ayarlar/bot.json");

exports.run = async (client, message, args) => {
let prefix = await db.fetch(`prefix.${message.guild.id}`) || ayarlar.prefix   
if(!message.member.permissions.has('MANAGE_MESSAGES')) return message.channel.send(new Discord.MessageEmbed().setColor("#000000").setTitle('Bir hata oldu!').setDescription(`${ayarlar.vanilya} Bu komutu kullanabilmek için \`Mesajları Yönet\` **yetkisine ihtiyacın var.**`)).then(m => m.delete({timeout: 10000}));

if(!args[0] || isNaN(args[0])) return message.channel.send(new Discord.MessageEmbed().setColor(`#00000`).setTitle(`Bir hata oldu!`).setDescription(`${ayarlar.vanilya} **Silinecek miktarı belirtmelisin!**

**Örnek:**
\`\`\`${prefix}sil 60\`\`\``)).then(a => a.delete({timeout: 15000}));

if(args[0] <= 0) return message.channel.send(new Discord.MessageEmbed().setColor(`#00000`).setTitle(`Bir hata oldu!`).setDescription(`${ayarlar.vanilya} **Belirttiğin miktar \`0'dan\` büyük olmalı!**`)).then(a => a.delete({timeout: 35000}));

if(args[0] > 100) return message.channel.send(new Discord.MessageEmbed().setColor("#000000").setTitle('Bir hata oldu!').setDescription(`${ayarlar.vanilya} **Bir kerede** \`100\` **üzeri mesajı silemem**`)).then(m => m.delete({timeout: 10000}));

  message.channel.bulkDelete(args[0]);


return message.channel.send(new Discord.MessageEmbed().setColor("#000000").setTitle('İşte bu kadar!').setDescription(`\`${args[0]}\``+` **adet mesaj silindi.** ${ayarlar.onayla}`)).then(m => m.delete({timeout: 5000}));
};

exports.config = {
  name: "sil2",
  aliases: ['temizle']
  }