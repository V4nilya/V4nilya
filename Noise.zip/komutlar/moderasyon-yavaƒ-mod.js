const Discord = require('discord.js');
const db = require('quick.db');
const ayarlar = require("../ayarlar/bot.json");

exports.run = async (client, message, args) => {

let prefix = await db.fetch(`prefix.${message.guild.id}`) || ayarlar.prefix   
if(!message.member.permissions.has('MANAGE_MESSAGES')) return message.channel.send(new Discord.MessageEmbed().setColor('#000000').setTitle('İşte bu kadar!').setDescription(`${ayarlar.vanilya} Bu komutu kullanabilmek için \`Mesajları Yönet\` **yetkisine ihtiyacın var.**`)).then(m => m.delete({timeout: 10000}));
if(!args[0] || isNaN(args[0])) return message.channel.send(new Discord.MessageEmbed().setColor('#000000').setTitle('Bir hata oldu!').setDescription(`${ayarlar.vanilya} ${message.author} **Yavaş mod için bir \`saniye\` belirtmedin!**

**Örnek:**
\`\`\`${prefix}yavaş-mod 60\`\`\``)).then(a => a.delete({timeout: 15000}));

if(args[0] > 21600) return message.channel.send(new Discord.MessageEmbed().setColor('#000000').setTitle('Bir hata oldu!').setDescription(`${ayarlar.vanilya} ${message.author} **Yavaş mod için en fazla \`21600\` saniye ayarlayabilirsin!**`)).then(a => a.delete({timeout: 10000}));
if(args[0] <= 0) return message.channel.send(new Discord.MessageEmbed().setColor(`#00000`).setTitle(`Bir hata oldu!`).setDescription(`${ayarlar.vanilya} **Belirttiğin miktar \`0'dan\` büyük olmalı!**`)).then(a => a.delete({timeout: 10000}));

message.channel.setRateLimitPerUser(args[0]);
return message.channel.send(new Discord.MessageEmbed().setColor('#000000').setTitle('İşte bu kadar!').setDescription(`${ayarlar.onayla} ${message.author} **Yavaş mod \`${args[0]}\` saniye olarak ayarlandı!**`)).then(a => a.delete({timeout: 10000}));
};

exports.config = {
  name: "yavaş-mod",
    aliases: []
  }