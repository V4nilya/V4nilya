const Discord = require(`discord.js`);

exports.run = (client, message, args) => {
  let kişicikabi = message.mentions.users.first() || message.author
 let avatar = new Discord.MessageEmbed()
  .setColor(`#000000`)
  .setAuthor(kişicikabi.tag ,kişicikabi.avatarURL())
  .setImage(kişicikabi.avatarURL({ dynamic: true, format:'png', size: 1024 }))
  .setTimestamp()
  .setFooter(`${message.author.username} tarafından kullanıldı`, client.user.avatarURL())
  return message.channel.send(avatar)
  };
  
exports.config = {
name: "avatar",
aliases: []
}