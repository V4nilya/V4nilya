
const Discord = require("discord.js")
const db = require('quick.db')
const ayarlar = require("../ayarlar/bot.json");

exports.run = async(bot, message, args) => {
let prefix = await db.fetch(`prefix.${message.guild.id}`) || ayarlar.prefix 
                    
if(!message.member.permissions.has(`ADMINISTRATOR`)) return message.channel.send(new Discord.MessageEmbed().setColor("#000000").setTitle(`Bir hata oldu!`).setDescription(`${ayarlar.vanilya} **Bu komutu kullanabilmek için \`Yönetici\` yetkisine ihtiyacın var.**`)).then(m => m.delete({timeout: 10000}));
                    
let komut = await db.fetch(`sunucuKomut_${message.guild.id}`) 
let gonderileceksey = await db.fetch(`sunucuMesaj_${message.guild.id}`)

let komut2 = await db.fetch(`sunucuKomut2_${message.guild.id}`) 
let gonderileceksey2 = await db.fetch(`sunucuMesaj2_${message.guild.id}`)

let komut3 = await db.fetch(`sunucuKomut3_${message.guild.id}`) 
let gonderileceksey3 = await db.fetch(`sunucuMesaj3_${message.guild.id}`)

if(!args[0]) return message.channel.send(new Discord.MessageEmbed().setColor("#000000").setTitle("Bir Hata Oldu!").setDescription(`${ayarlar.vanilya} **Lütfen silmek istediğiniz oto-cevabı giriniz.**\n**${ayarlar.vanilya} Mevcut özel komut-cevaplar: \`${komut}\` - \`${komut2}\` - \`${komut3}\`**`))
if(args[0] == 'Ayarlanmadı.') return message.channel.send(new Discord.MessageEmbed().setColor("#000000").setTitle("Bir Hata Oldu!").setDescription(`${ayarlar.vanilya} **Lütfen silmek istediğiniz oto-cevabı giriniz.**\n**${ayarlar.vanilya} Mevcut özel komut-cevaplar: \`${komut}\` - \`${komut2}\` - \`${komut3}\`**`))

if (args[0] == komut) 
{

  message.channel.send(new Discord.MessageEmbed().setColor("#000000").setTitle("İşte Bu Kadar!").setDescription(`**\`${komut}\` oto-cevabı silindi. ${ayarlar.onayla}**`))

db.set(`sunucuKomut_${message.guild.id}`, 'Ayarlanmadı.')
db.delete(`sunucuMesaj_${message.guild.id}`, gonderileceksey)

}

else if (args[0] == komut2) 
{

  message.channel.send(new Discord.MessageEmbed().setColor("#000000").setTitle("İşte Bu Kadar!").setDescription(`**\`${komut2}\` oto-cevabı silindi. ${ayarlar.onayla}**`))

db.set(`sunucuKomut2_${message.guild.id}`, 'Ayarlanmadı.')
db.delete(`sunucuMesaj2_${message.guild.id}`, gonderileceksey2)
}
  
else if (args[0] == komut3) 
{

  message.channel.send(new Discord.MessageEmbed().setColor("#000000").setTitle("İşte Bu Kadar!").setDescription(`**\`${komut3}\` oto-cevabı silindi. ${ayarlar.onayla}**`))

db.set(`sunucuKomut3_${message.guild.id}`, 'Ayarlanmadı.')
db.delete(`sunucuMesaj3_${message.guild.id}`, gonderileceksey3)

}
};

exports.config = {
  name: "otocevap-sil",
    aliases: []
}

