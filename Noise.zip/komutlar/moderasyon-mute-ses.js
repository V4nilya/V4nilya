const Discord = require('discord.js');
const db = require('quick.db');
const ms = require('ms');
const ayarlar = require("../ayarlar/bot.json");

exports.run = async (client, message, args) => {
  let prefix = await db.fetch(`prefix.${message.guild.id}`) || ayarlar.prefix   

  const logChannel = await db.fetch(`mute.log.${message.guild.id}`);
  if(!logChannel) return message.channel.send(new Discord.MessageEmbed().setTitle('Bir hata oldu!').setColor("#000000").setDescription(`${ayarlar.vanilya} **\`Mute-Log\` kanalının ayarlanması gerek!**
  
  **Örnek kullanım:**
  \`\`\`${prefix}mute-log #mutelog-kanalı\`\`\``)).then(a => a.delete({timeout: 10000}));
  
  const muteYetkili = await db.fetch(`muteses.yetki.${message.guild.id}`);
  if(!muteYetkili) return message.channel.send(new Discord.MessageEmbed().setTitle('Bir hata oldu!').setColor("#000000").setDescription(`${ayarlar.vanilya} **\`Mute-Ses-Yetkilisi\` rolünün ayarlanması gerek!**
  
  **Örnek kullanım:**
  \`\`\`${prefix}mute-ses-yetkili @rol\`\`\``)).then(a => a.delete({timeout: 10000}));

  if(!message.member.permissions.has(muteYetkili)) return message.channel.send(new Discord.MessageEmbed().setColor("#000000").setDescription(`${message.guild.roles.cache.get(muteYetkili)} | Rolüne sahip olman gerekiyor.`));

  let mutekisi = message.guild.member(message.mentions.users.first() || message.guild.members.cache.get(args[0]));
  if(!mutekisi) return message.channel.send(new Discord.MessageEmbed().setColor("#000000").setTitle('Bir hata oldu!').setDescription(`**${ayarlar.vanilya} Bir üye etiketlemelisin veya id girmelisin**

  **Örnek kullanım:**
  \`\`\`${prefix}mute-ses @üye 1dk küfür
  
${prefix}mute-ses 916287683275603488 1dk küfür\`\`\``).setTimestamp().setFooter(`${message.author.username} tarafından kullanıldı`, client.user.avatarURL()));
 
  if(message.author.id === mutekisi.id) return message.channel.send(new Discord.MessageEmbed().setColor("#000000").setTitle(`Çok şey istiyorsun`).setDescription(`**${ayarlar.sahip} Bunu yapamam dostum.**`))
  if(mutekisi.roles.highest.position >= message.member.roles.highest.position) return message.channel.send(new Discord.MessageEmbed().setColor("#000000").setDescription(`**${ayarlar.vanilya} Senden üst veya sana eşit birisini muteleyemem.**`));
  if(mutekisi.hasPermission("ADMINISTRATOR")) return message.channel.send(new Discord.MessageEmbed().setColor("#000000").setDescription(`**${ayarlar.vanilya} Yönetici bir kullanıcıya karışamam!**`));
 
let mutezaman = args[1];
if(mutezaman) {
  mutezaman = args[1].replace(`sn`, `s`).replace(`dk`, `m`).replace(`sa`, `h`).replace(`gün`, `d`)}
  if (!mutezaman) return message.channel.send(new Discord.MessageEmbed().setColor("#000000").setTitle('Bir hata oldu!').setDescription(`**${ayarlar.vanilya} Süre belirtmen gerekli! \`1sn - 1dk - 1sa  1gün\` kullanarak**
  **dener misin?**
  
  **Örnek kullanım:**
  \`\`\`${prefix}mute-ses @üye 1dk küfür\`\`\``).setTimestamp().setFooter(`${message.author.username} tarafından kullanıldı`, client.user.avatarURL()));

  if(!args[2]) return message.channel.send(new Discord.MessageEmbed().setColor("#000000").setTitle('Bir hata oldu!').setDescription(`**${ayarlar.vanilya} Sebep belirtmen gerekli!**

  **Örnek kullanım:**
  \`\`\`${prefix}mute-ses @üye 1dk küfür\`\`\``).setTimestamp().setFooter(`${message.author.username} tarafından kullanıldı`, client.user.avatarURL()));
  
  let sebep = args[2];

  message.guild.channels.cache.filter(a => a.type === 'voice').forEach(s => {
    s.overwritePermissions([{ id: mutekisi.id, deny: ['SPEAK'] }]);
    });

  message.channel.send(new Discord.MessageEmbed()
  .setAuthor(`Vanitas`, client.user.avatarURL())
  .setColor("#000000")
  .addField("Susturulan Kullanıcı", `<@${mutekisi.id}>`)
  .addField("Susturulma Sebebi", `**\`${sebep}\`**`)
  .addField("Ceza Süresi", `**\`${args[1]}\`**`)
  .setFooter(`Vanitas | Susturma Sistemi`, client.user.avatarURL())
  .setTimestamp());

  let embed = new Discord.MessageEmbed()
  .setAuthor(`Vanitas`, client.user.avatarURL())
  .setColor("#000000")
  .addField("Eylem", "\`Sesli Susturma\`")
  .addField("Kullanıcıyı Susturan Yetkili", `<@${message.author.id}>`)
  .addField("Susturulan Kullanıcı", `<@${mutekisi.id}>`)
  .addField("Susturulma Sebebi", `**\`${sebep}\`**`)
  .addField("Ceza Süresi", `**\`${args[1]}\`**`)
  .setFooter(`Vanitas | Susturma Sistemi`, client.user.avatarURL())
  .setTimestamp();
  client.channels.cache.get(logChannel).send(embed);

  setTimeout(() => {
    message.guild.channels.cache.filter(a => a.type === 'voice').forEach(s => {
    s.overwritePermissions([{ id: mutekisi.id, null: ['SPEAK'] }]);
    });
    }, ms(mutezaman));
}

exports.config = {
  name: "mute-ses",
    aliases: []
}
