const Discord = require(`discord.js`)
const db = require(`quick.db`);
const ayarlar = require(`../ayarlar/bot.json`)

exports.run = async (client, message, args) => {
const embed = new Discord.MessageEmbed()
let a = ayarlar.prefix
    let p = await db.fetch(`prefix.${message.guild.id}`) || ayarlar.prefix
 let o = await db.fetch(`prefix.${message.guild.id}`)
  if(!message.member.permissions.has(`MANAGE_MESSAGES`)) return message.channel.send(embed.setColor("#000000").setTitle(`Bir hata oldu!`).setDescription(`${ayarlar.vanilya} **Bu komutu kullanabilmek için \`Mesajları Yönet\` yetkisine ihtiyacın var. | Şu anki prefix:** ${p}`)).then(m => m.delete({timeout: 10000}));
  
if(args[0] === "ayarla") {
if(o) { return message.channel.send(embed.setColor("#000000").setDescription(`**Prefix Zaten Ayarlanmış | Şu anki Prefix:** \`${p}\`\n **Sıfırlamak İçin** \`${p}prefix sıfırla\``)).then(m => m.delete({timeout: 10000})); 
     }
if(!args[1]) return message.channel.send(embed.setColor("#000000").setDescription(`${ayarlar.vanilya}  **Bir Prefix Girip Yeniden Dene |  Şu anki Prefix:** \`${p}\``)).then(m => m.delete({timeout: 10000}));
db.set(`prefix.${message.guild.id}`, args[1])
message.channel.send(embed.setColor("#000000").setDescription(`${ayarlar.vanilya}  **Prefix Başarıyla Ayarlandı | Şu anki Prefix:** \`${args[1]}\``)).then(m => m.delete({timeout: 10000}));
}
    if(args[0] === "sıfırla") {
    if(!o) {
       return message.channel.send(embed.setColor("#000000").setDescription(`${ayarlar.vanilya} **Ayarlanmayan Prefixi Sıfırlayamazsınız | Şu anki Prefix:** \`${p}\``)).then(m => m.delete({timeout: 10000}));
    }
    db.delete(`prefix.${message.guild.id}`)       
   return message.channel.send(embed.setColor("#000000").setDescription(`${ayarlar.vanilya} **Prefix Başarıyla Sıfırlandı | Şu anki Prefix:** \`${a}\``)).then(m => m.delete({timeout: 10000}));
  }
 if(!args[0]) return message.channel.send(embed.setColor("#000000").setTimestamp().setAuthor(`${ayarlar.botisim}`, client.user.avatarURL()).setFooter(`${message.author.username} tarafından kullanıldı`, client.user.avatarURL()).setDescription(`${ayarlar.vanilya} **Prefix ayarlamak için** \`${p}prefix ayarla <prefix>\`\n ${ayarlar.vanilya} **Sıfırlamak için** \`${p}prefix sıfırla\``)).then(m => m.delete({timeout: 20000}));

};

exports.config = {
name: "prefix",
aliases: []
};