const Discord = require('discord.js');
const db = require('quick.db');
const ms = require('ms');
const ayarlar = require("../ayarlar/bot.json");

exports.run = async (client, message, args) => {
  let prefix = await db.fetch(`prefix.${message.guild.id}`) || ayarlar.prefix 

const logChannel = await db.fetch(`jail.log.${message.guild.id}`);
if(!logChannel) return message.channel.send(new Discord.MessageEmbed().setTitle('Bir hata oldu!').setColor("#000000").setDescription(`${ayarlar.vanilya} **\`Jail-Log\` kanalının ayarlanması gerek!**
  
**Örnek kullanım:**
\`\`\`${prefix}jail-log #jaillog-kanalı\`\`\``)).then(a => a.delete({timeout: 10000}));

const jailYetkili = await db.fetch(`jail.yetki.${message.guild.id}`);
if(!jailYetkili) return message.channel.send(new Discord.MessageEmbed().setTitle('Bir hata oldu!').setColor("#000000").setDescription(`${ayarlar.vanilya} **\`Jail-Yetkilisi\` rolünün ayarlanması gerek!**
  
**Örnek kullanım:**
\`\`\`${prefix}jail-yetkili-rol @rol\`\`\``)).then(a => a.delete({timeout: 10000}));

const karantinaRole = await db.fetch(`jail.karantina.${message.guild.id}`);
if(!karantinaRole) return message.channel.send(new Discord.MessageEmbed().setTitle('Bir hata oldu!').setColor("#000000").setDescription(`${ayarlar.vanilya} **\`Jail-Karantina\` rolünün ayarlanması gerek!**
  
**Örnek kullanım:**
\`\`\`${prefix}jail-karantina-rol @rol\`\`\``)).then(a => a.delete({timeout: 10000}));

const masumRole = await db.fetch(`jail.tahliye.${message.guild.id}`);
if(!masumRole) return message.channel.send(new Discord.MessageEmbed().setTitle('Bir hata oldu!').setColor("#000000").setDescription(`${ayarlar.vanilya} **\`Jail-Tahliye\` rolünün ayarlanması gerek!**
  
**Örnek kullanım:**
\`\`\`${prefix}jail-tahliye-rol @rol\`\`\``)).then(a => a.delete({timeout: 10000}));

if(!message.member.roles.cache.has(jailYetkili)) return message.channel.send(new Discord.MessageEmbed().setColor("#000000").setDescription(`**${ayarlar.vanilya} Jail komutu için ${message.guild.roles.cache.get(jailYetkili)} rolüne sahip olman gerekiyor.**`)).then(a => a.delete({timeout: 10000}));

let member = message.guild.member(message.mentions.users.first() || message.guild.members.cache.get(args[0]));
if(!member) return message.channel.send(new Discord.MessageEmbed().setColor("#000000").setTitle('Bir hata oldu!').setDescription(`**${ayarlar.vanilya} Bir üye etiketlemelisin veya id girmelisin**

**Örnek kullanım:**
\`\`\`${prefix}jail @üye 1dk terbiyesizlik

${prefix}jail 916287683275603488 1dk terbiyesizlik\`\`\``).setTimestamp().setFooter(`${message.author.username} tarafından kullanıldı`, client.user.avatarURL())).then(a => a.delete({timeout: 15000}));

if(message.author.id === member.id) return message.channel.send(new Discord.MessageEmbed().setColor("#000000").setTitle(`Çok şey istiyorsun`).setDescription(`**${ayarlar.sahip} Bunu yapamam dostum.**`)).then(a => a.delete({timeout: 15000}));
if(member.roles.highest.position >= message.member.roles.highest.position) return message.channel.send(new Discord.MessageEmbed().setColor("#000000").setDescription(`**${ayarlar.vanilya} Senden üst veya sana eşit birisini muteleyemem.**`)).then(a => a.delete({timeout: 15000}));
if(member.hasPermission("ADMINISTRATOR")) return message.channel.send(new Discord.MessageEmbed().setColor("#000000").setDescription(`**${ayarlar.vanilya} Yönetici bir kullanıcıya karışamam!**`)).then(a => a.delete({timeout: 15000}));

let jailzaman = args[1];
if(jailzaman) {
  jailzaman = args[1].replace(`sn`, `s`).replace(`dk`, `m`).replace(`sa`, `h`).replace(`gün`, `d`)}
  if (!jailzaman) return message.channel.send(new Discord.MessageEmbed().setColor("#000000").setTitle('Bir hata oldu!').setDescription(`**${ayarlar.vanilya} Süre belirtmen gerekli! \`1sn - 1dk - 1sa  1gün\` kullanarak**
  **dener misin?**
  
  **Örnek kullanım:**
  \`\`\`${prefix}jail @üye 1dk terbiyesizlik\`\`\``).setTimestamp().setFooter(`${message.author.username} tarafından kullanıldı`, client.user.avatarURL())).then(a => a.delete({timeout: 15000}));

  if(!args[2]) return message.channel.send(new Discord.MessageEmbed().setColor("#000000").setTitle('Bir hata oldu!').setDescription(`**${ayarlar.vanilya} Sebep belirtmen gerekli!**

  **Örnek kullanım:**
  \`\`\`${prefix}jail @üye 1dk terbiyesizlik\`\`\``).setTimestamp().setFooter(`${message.author.username} tarafından kullanıldı`, client.user.avatarURL())).then(a => a.delete({timeout: 15000}));
  
  let sebep = args[2];

member.roles.cache.forEach(rol => {
  if (rol.id === member.guild.id) return;
  member.roles.remove(rol.id)
})
member.roles.add(karantinaRole);


message.channel.send(new Discord.MessageEmbed()
.setAuthor(`Vanitas`, client.user.avatarURL())
.setColor("#000000")
.addField("Jaile Atılan Üye", `<@${member.id}>`)
.addField("Jaile Atılma Sebebi", `**\`${sebep}\`**`)
.addField("Ceza Süresi", `**\`${args[1]}\`**`)
.setFooter(`Vanitas | Jail Sistemi`, client.user.avatarURL())
.setTimestamp());

let embed = new Discord.MessageEmbed()
.setAuthor(`Vanitas`, client.user.avatarURL())
.setColor("#000000")
.addField("Eylem", "\`Jail\`")
.addField("Jaile Atan Yetkili", `<@${message.author.id}>`)
.addField("Jaile Atılan Üye", `<@${member.id}>`)
.addField("Jaile Atılma Sebebi", `**\`${sebep}\`**`)
.addField("Ceza Süresi", `**\`${args[1]}\`**`)
.setFooter(`Vanitas | Jail Sistemi`, client.user.avatarURL())
.setTimestamp();
client.channels.cache.get(logChannel).send(embed);

setTimeout(() => {
  member.roles.remove(karantinaRole);
  member.roles.add(masumRole);
    }, ms(jailzaman));

};

exports.config = {
  name: "jail",
    aliases: []
}