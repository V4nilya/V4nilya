const Discord = require('discord.js');

exports.run = async (client, message, args) => {

  if (message.deletable) await message.delete();
  if (!message.guild.me.permissions.has('MANAGE_MESSAGES')) return message.channel.send(`${message.author} \`Webhookları Yönet\` iznim yok.`).then(a => a.delete({timeout: 4500}));
 
  let YazılacakMesaj = args[0]

  let Kullanıcı = await client.users.fetch(message.author.id);
  try {
  return message.channel.createWebhook(Kullanıcı.username, {
      avatar: Kullanıcı.avatarURL()})
    .then(async (wb) => {
        const Webhook = new Discord.WebhookClient(wb.id, wb.token);
        await Webhook.send("<a:kalp:921418401820332032>");
        setTimeout(() => {
          Webhook.delete()
        }, 2000);
    })
  } catch (err) {
    return message.channel.send(err);
};
}

exports.config = {
    name: "emoji",
      aliases: ["e"]
  }
