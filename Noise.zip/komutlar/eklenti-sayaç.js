const Discord = require(`discord.js`);
const db = require(`quick.db`);
const ayarlar = require("../ayarlar/bot.json");

exports.run = (client, message, args) => { 
const vanitas = new Discord.MessageEmbed()
let kanal = message.mentions.channels.first() 
let sayı = args[1]
let kalan = args[1] - message.guild.memberCount
if(!message.member.permissions.has(`ADMINISTRATOR`)) return message.channel.send(new Discord.MessageEmbed().setColor("#000000").setTitle(`Bir hata oldu!`).setDescription(`${ayarlar.vanilya} **Bu komutu kullanabilmek için \`Yönetici\` yetkisine ihtiyacın var.**`)).then(m => m.delete({timeout: 10000}));

if(args[0] === `kapat`) {
  db.delete(`sayacK_${message.guild.id}`);
  db.delete(`sayacS_${message.guild.id}`);
  return message.channel.send(new Discord.MessageEmbed().setColor(`#00000`).setTitle(`İşte bu kadar!`).setDescription(`${ayarlar.onayla} **Sayaç sistemi başarıyla kapatıldı!**`)).then(a => a.delete({timeout: 15000}));

} else {
  
if(!kanal) return message.channel.send(vanitas.setColor("#000000").setTitle(`Kullanım:`).setDescription(`${ayarlar.vanilya} **Bir kanal belirtmelisin.**`)).then(a => a.delete({timeout: 10000}));
 if(isNaN(args[1])) return message.channel.send(vanitas.setColor("#000000").setTitle(`Kullanım:`).setDescription(`${ayarlar.vanilya} **Birde sayı belirtmelisin.**`)).then(a => a.delete({timeout: 10000}));
 if(message.guild.memberCount > args[1]) return message.channel.send(vanitas.setColor("#000000").setTitle(`Bir hata oldu!`).setDescription(`${ayarlar.vanilya} **Belirttiğin sayıya çoktan ulaşmışsın!**`)).then(a => a.delete({timeout: 10000}));

db.set(`sayacK_${message.guild.id}`, kanal.id)  
db.set(`sayacS_${message.guild.id}`, sayı) 
return message.channel.send(vanitas.setColor("#000000").setTitle(`İşte bu kadar!`).setDescription(`${ayarlar.onayla} **Sayaç aktif edildi. Hedef üye sayısı \`${args[1]}\`, sayaç kanalı ise ${kanal} olarak ayarlandı!**`)).then(a => a.delete({timeout: 15000}));

}
};

exports.config = {
  name: "sayaç",
    aliases: []
  }
