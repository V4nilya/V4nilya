const Discord = require('discord.js');
const db = require('quick.db');
const ayarlar = require("../ayarlar/bot.json");

exports.run = async (client, message, args) => {
let prefix = await db.fetch(`prefix.${message.guild.id}`) || ayarlar.prefix 
const embed = new Discord.MessageEmbed().setThumbnail();
let rol = message.mentions.roles.first() 
if(!message.member.permissions.has('ADMINISTRATOR')) return message.channel.send(embed.setColor("#000000").setTitle('Bir hata oldu!').setDescription(`${ayarlar.vanilya} **Bu komutu kullanabilmek için \`Yönetici\` yetkisine ihtiyacın var.**`)).then(m => m.delete({timeout: 10000}));

if(args[0] === `sıfırla`) {
  const rol = db.fetch(`erkek.${message.guild.id}`)  
  if(!rol) return message.reply(embed.setColor("#000000").setTitle(`Bir hata oldu!`).setDescription(`${ayarlar.vanilya} **\`Erkek\` rolü zaten ayarlanmamış!**`)).then(a => a.delete({timeout: 35000}));
  db.delete(`erkek.${message.guild.id}`);
  return message.channel.send(new Discord.MessageEmbed().setColor(`#00000`).setTitle(`İşte bu kadar!`).setDescription(`${ayarlar.onayla} **\`Kayıt-Erkek\` rolü sıfırlandı!**`)).then(a => a.delete({timeout: 15000}));

} else {

if(!rol) return message.channel.send(embed.setColor("#000000").setTitle(`Kullanım:`).setDescription(`${ayarlar.vanilya} **Bir rol belirtmelisin!**

**Örnek kullanım:**
\`\`\`${prefix}erkek-rol @erkek-rolü\`\`\``)).then(a => a.delete({timeout: 10000}));

db.set(`erkek.${message.guild.id}`, rol.id)  
return message.channel.send(embed.setColor("#000000").setTitle(`İşte bu kadar!`).setDescription(`${ayarlar.onayla} **Kayıt-Erkek rolü ${rol} olarak ayarlandı!**`)).then(a => a.delete({timeout: 15000}));
}
};


exports.config = {
  name: "erkek-rol",
    aliases: []
  }