const Discord = require('discord.js');
const db = require('quick.db');
const ayarlar = require("../ayarlar/bot.json");

    exports.run = async (client, message, args) => { 

        let kisi = message.guild.members.cache.get(message.author.id);
        let kisiisim = kisi.displayName;

        let afk = db.fetch(`kisiid_${message.author.id}_${message.guild.id}`);
        if(afk) return message.reply(new Discord.MessageEmbed().setColor("#000000").setTimestamp().setTitle(`Bir hata oldu!`).setDescription(`** ${ayarlar.vanilya} ${message.author} Zaten afksın!**`)).then(a => a.delete({timeout: 35000}));

        if(!args[0]) {

            db.set(`afk_sebep_${message.author.id}_${message.guild.id}`, 'Sebep Belirtilmedi');
            db.set(`kisiid_${message.author.id}_${message.guild.id}`,message.author.id);
            db.set(`kisiisim_${message.author.id}_${message.guild.id}`, kisiisim);

            let sebep = db.fetch(`afk_sebep_${message.author.id}_${message.guild.id}`);

            const afk = new Discord.MessageEmbed()
            .setTitle(`İşte Bu Kadar!`)
            .setDescription(`**${ayarlar.onayla} ${message.author} Başarılı şekilde \`${sebep}\` Sebebiyle \`AFK\` moduna geçtin.**`)
            .setColor('#000000')
            .setTimestamp()
            .setFooter(`${message.author.username} tarafından kullanıldı`, client.user.avatarURL())
            message.channel.send(afk).then(a => a.delete({timeout: 35000}));
            message.member.setNickname(`[AFK] ` + kisiisim);
        }

        if(args[0]) {
            let cmfsebep = args.join(' ');
        
            db.set(`afk_sebep_${message.author.id}_${message.guild.id}`, cmfsebep);
            db.set(`kisiid_${message.author.id}_${message.guild.id}`,message.author.id);
            db.set(`kisiisim_${message.author.id}_${message.guild.id}`, kisiisim);

            let sebep = db.fetch(`afk_sebep_${message.author.id}_${message.guild.id}`);

            const afk = new Discord.MessageEmbed()
            .setTitle(`İşte Bu Kadar!`)
            .setDescription(`**${ayarlar.onayla} ${message.author} Başarılı şekilde \`${sebep}\` Sebebiyle \`AFK\` moduna geçtin.**`)
            .setColor('#000000')
            .setTimestamp()
            .setFooter(`${message.author.username} tarafından kullanıldı`, client.user.avatarURL())
            message.channel.send(afk).then(a => a.delete({timeout: 35000}));
            message.member.setNickname(`[AFK] ` + kisiisim);
        }
    }

exports.config = {
name: "afk",
aliases: []
}