const Discord = require(`discord.js`);
const db = require(`quick.db`);
const ayarlar = require("../ayarlar/bot.json");

exports.run = async (client, message, args) => {
let prefix = db.fetch(`prefix.${message.guild.id}`) || ayarlar.prefix 
let vanitas = new Discord.MessageEmbed() 
.setColor(`#000000`)
.setAuthor(`${ayarlar.botisim}${ayarlar.isim_eki} rolünü yukarıda tutmayı unutmayın!`, client.user.avatarURL())
.setDescription(`
\`\`\`          [ Kurulum Komutları ]       \`\`\`
<a:vanitas:901857063171411979> \`${prefix}tagrol-tag ⭐\`
**Önce tagımızı belirleyelim, daha sonra değiştirebilirsin.**

<a:vanitas:901857063171411979> \`${prefix}tagrol-rol @rol\`
**Tag alan kişiye verilecek rolü ayarlıyalım.**

<a:vanitas:901857063171411979> \`${prefix}tagrol-log #kanal\`
**Tag alma & çıkarma eylemlerini kaydedeceğim.**

\`\`\`        [ Sıfırlama Komutları ]       \`\`\`
<a:vanitas:901857063171411979> \`${prefix}tagrol-tag kapat\`
**Tagrol sistemini kapatır.**

<a:vanitas:901857063171411979> \`${prefix}tagrol-rol sil\`
**Tag alınca verilecek olan rolü siler.**

<a:vanitas:901857063171411979> \`${prefix}tagrol-log sil\`
**Ayarladığınız tag kanalı siler.**`)
.setTimestamp()
.setFooter(`${message.author.username} tarafından kullanıldı`, client.user.avatarURL())
message.channel.send(vanitas).then(a => a.delete({timeout: 150000}));
};

exports.config = {
  name: "tagrol-sistem",
    aliases: []
  }