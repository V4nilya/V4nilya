const Discord = require(`discord.js`);
const db = require(`quick.db`);
const ayarlar = require("../ayarlar/bot.json");

exports.run = async (client, message, args) => {
let prefix = await db.fetch(`prefix.${message.guild.id}`) || ayarlar.prefix 
let vanitas = new Discord.MessageEmbed() 
.setColor(`#000001`)
.setAuthor(`${ayarlar.botisim}${ayarlar.isim_eki} rolünü yukarıda tutmayı unutmayın!`, client.user.avatarURL())
.setDescription(`
\`\`\`          [ Kurulum Komutları ]        \`\`\`
${ayarlar.vanilya} \`${prefix}otoisim\`
**kurulumu yapacağız, lütfen komutu yaz.**

${ayarlar.vanilya} \`${prefix}otoisim-log #kanal\`
**İstersen bu eylemleri kayıt altına alabilirsin.**

\`\`\`          [ Kapatma Komutları ]          \`\`\`
${ayarlar.vanilya} \`${prefix}otoisim kapat\`
**Oto isim sistemini kapatır.**

${ayarlar.vanilya} \`${prefix}otoisim-log kapat\`
**Ayarlı olan log kanalını kapatır.**`)
.setTimestamp()
.setFooter(`${message.author.username} tarafından kullanıldı`, client.user.avatarURL())
return message.channel.send(vanitas).then(a => a.delete({timeout: 50000}));
};
exports.config = {
  name: "otoisim-sistem",
    aliases: []
  }